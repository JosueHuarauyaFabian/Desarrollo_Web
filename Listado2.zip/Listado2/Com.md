### 1. **Instalación de Node.js y npm (si no están instalados):**
   - Instalando Node.js y npm en el sistema, primero se debe instalarlo. Dependiendo del sistema operativo, puedes hacerlo así:
   
     - **En Windows/macOS:**
       - Descarga e instala Node.js desde la página oficial: [Node.js](https://nodejs.org/).
       - Esto instalará tanto `node` como `npm` automáticamente.

     - **En Linux (Ubuntu/Debian):**
       - Abre una terminal y ejecuta los siguientes comandos para instalar Node.js y npm:
         ```bash
         sudo apt update
         sudo apt install nodejs
         sudo apt install npm
         ```

     - **Verifica la instalación ejecutando:**
       ```bash
       node -v
       npm -v
       ```

### 2. **Inicialización del proyecto con npm:**
   - Crea una nueva carpeta para tu proyecto y navega hacia ella:
     ```bash
     mkdir mi-proyecto-typescript
     cd mi-proyecto-typescript
     ```

   - Inicializa un nuevo proyecto Node.js y genera el archivo `package.json`:
     ```bash
     npm init -y
     ```

### 3. **Instalación de TypeScript:**
   - Instala TypeScript como una dependencia de desarrollo:
     ```bash
     npm install typescript --save-dev
     ```

   - Para verificar que TypeScript se ha instalado correctamente, ejecuta:
     ```bash
     npx tsc --version
     ```

### 4. **Creación del archivo de configuración `tsconfig.json`:**
   - Ejecuta el siguiente comando para generar el archivo de configuración de TypeScript:
     ```bash
     npx tsc --init
     ```

   - Esto creará un archivo `tsconfig.json` con la configuración predeterminada. Para modificarlo con las opciones avanzadas recomendadas, abre el archivo y ajusta las opciones como se indica:
     ```json
     {
       "compilerOptions": {
         "target": "ES6",
         "strict": true,
         "noImplicitAny": true,
         "module": "commonjs",
         "outDir": "./dist"
       }
     }
     ```

### 5. **Creación del archivo `index.ts`:**
   - Crea un archivo llamado `index.ts` dentro de la carpeta del proyecto:
     ```bash
     touch index.ts
     ```

   - Abre el archivo `index.ts` en tu editor de texto preferido (Visual Studio Code es recomendado) y añade el siguiente código:
     ```typescript
     const greet = (name: string): string => {
       return `Hello, ${name}!`;
     }

     console.log(greet("World"));
     ```

### 6. **Compilación del código TypeScript:**
   - Ahora que tienes el código en TypeScript y configurado correctamente, compílalo utilizando TypeScript:
     ```bash
     npx tsc
     ```

   - Esto generará un archivo JavaScript compilado en la carpeta `dist` (la carpeta `outDir` especificada en `tsconfig.json`).

### 7. **Ejecución del código compilado:**
   - Para ejecutar el código JavaScript generado, navega a la carpeta `dist` y ejecuta el archivo:
     ```bash
     node dist/index.js
     ```

   - Deberías ver en la terminal el siguiente resultado:
     ```
     Hello, World!
     ```

### 8. **Comandos adicionales recomendados para producción:**
   - Si estás preparando el proyecto para producción, puedes utilizar las siguientes opciones:
     - **Eliminar variables y parámetros no utilizados**:
       En el archivo `tsconfig.json`, añade las siguientes opciones:
       ```json
       "noUnusedLocals": true,
       "noUnusedParameters": true
       ```

     - **Deshabilitar source maps (mapas de origen)** para producción:
       ```json
       "sourceMap": false
       ```

### 9. **Instalar un gestor de tareas (opcional):**
   Si deseas automatizar el proceso de compilación, puedes instalar una herramienta como `ts-node` o `nodemon`.

   - **Instalar nodemon** (para reiniciar automáticamente el servidor):
     ```bash
     npm install --save-dev nodemon
     ```

   - Configura un script en `package.json` para iniciar automáticamente con `nodemon`:
     ```json
     "scripts": {
       "start": "nodemon dist/index.js",
       "build": "npx tsc"
     }
     ```

   - Ejecuta el script con:
     ```bash
     npm run build
     npm start
     ```

---

### Resumen de Comandos:
1. **Instalación de Node.js y npm:**
   ```bash
   sudo apt update
   sudo apt install nodejs
   sudo apt install npm
   ```

2. **Inicialización del proyecto:**
   ```bash
   mkdir mi-proyecto-typescript
   cd mi-proyecto-typescript
   npm init -y
   ```

3. **Instalación de TypeScript:**
   ```bash
   npm install typescript --save-dev
   npx tsc --init
   ```

4. **Creación de `index.ts`:**
   ```bash
   touch index.ts
   ```

5. **Compilación del código:**
   ```bash
   npx tsc
   node dist/index.js
   ```

6. **Instalación de `nodemon` (opcional):**
   ```bash
   npm install --save-dev nodemon
   ```

