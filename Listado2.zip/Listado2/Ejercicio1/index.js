"use strict";
const greet = (name) => {
    return `Hello, ${name}!`;
};
console.log(greet("World"));
