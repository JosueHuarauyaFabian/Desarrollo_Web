### **Ejercicio 10: Generación de tipos dinámicos**

#### **Descripción del problema:**
Crea un generador de formularios en una aplicación web. Define una interfaz `FormField` que pueda representar diferentes tipos de campos (input, textarea, select). Usa **generics** para permitir que el generador de formularios acepte tipos dinámicos de datos y valide que los valores proporcionados coincidan con el tipo de campo definido.

---

### **Solución:**

#### **Paso 1: Definir la interfaz `FormField`**
La interfaz `FormField` va a representar un campo de formulario, y dependiendo del tipo (`input`, `textarea`, `select`), tendrá diferentes valores y validaciones.

```typescript
// Definición de FormField con un tipo genérico T para representar el tipo de valor
interface FormField<T> {
  type: 'input' | 'textarea' | 'select';
  label: string;
  value: T;
  options?: T[];  // Solo para el tipo select
}
```

- **`FormField<T>`**: Es una interfaz genérica que acepta un tipo `T`, que representa el tipo de valor que el campo puede tener.
  - `type`: Indica si el campo es de tipo `input`, `textarea` o `select`.
  - `value`: El valor del campo debe coincidir con el tipo `T`.
  - `options`: Solo para campos `select`, contiene las opciones disponibles.

---

#### **Paso 2: Crear una función para validar los datos de entrada**
Ahora implementamos una función que valide los valores proporcionados para cada tipo de campo. Utilizaremos **generics** para asegurarnos de que el tipo de dato del valor coincida con el tipo de campo.

```typescript
// Función para validar un campo de formulario genérico
function validateField<T>(field: FormField<T>, inputValue: T): boolean {
  // Si el campo es de tipo select, validamos que el valor esté en las opciones
  if (field.type === 'select' && field.options) {
    return field.options.includes(inputValue);
  }
  // Para input y textarea, simplemente verificamos el tipo de dato
  return typeof inputValue === typeof field.value;
}
```

- **`validateField<T>`**: Esta función genérica toma un campo de tipo `FormField<T>` y un valor `inputValue` que debe ser del mismo tipo que `T`. Si el campo es de tipo `select`, se asegura de que el valor esté dentro de las opciones disponibles. Para los otros tipos, verifica que el tipo del valor sea correcto.

---

#### **Paso 3: Crear algunos campos de ejemplo**
A continuación, creamos algunos campos de formulario de diferentes tipos para probar la funcionalidad.

```typescript
// Campos de ejemplo
const nameField: FormField<string> = {
  type: 'input',
  label: 'Name',
  value: '',
};

const descriptionField: FormField<string> = {
  type: 'textarea',
  label: 'Description',
  value: '',
};

const selectField: FormField<string> = {
  type: 'select',
  label: 'Choose an option',
  value: '',
  options: ['Option 1', 'Option 2', 'Option 3'],
};
```

- **`nameField`**: Un campo `input` que acepta un `string`.
- **`descriptionField`**: Un campo `textarea` que también acepta un `string`.
- **`selectField`**: Un campo `select` que acepta un `string` y tiene opciones predefinidas.

---

#### **Paso 4: Probar la función de validación**
Probamos la función `validateField` con diferentes valores de entrada para ver si la validación funciona correctamente.

```typescript
// Pruebas de validación
console.log(validateField(nameField, 'John Doe'));  // true
console.log(validateField(descriptionField, 'This is a description'));  // true
console.log(validateField(selectField, 'Option 1'));  // true
console.log(validateField(selectField, 'Invalid Option'));  // false
```

En las pruebas, la función debe devolver `true` si el valor proporcionado es válido para el tipo de campo, y `false` si no lo es.

---

### **Respuestas a las preguntas de análisis:**

1. **¿Cómo utilizas generics para crear componentes reutilizables?**
   - Los **generics** permiten crear componentes reutilizables porque pueden adaptarse a diferentes tipos de datos sin necesidad de escribir el código para cada caso específico. En este ejemplo, la interfaz `FormField<T>` y la función `validateField<T>` pueden manejar cualquier tipo de dato (`string`, `number`, etc.) al definir dinámicamente el tipo `T`. Esto evita la duplicación de código y asegura que la funcionalidad sea flexible y segura.

2. **¿Qué ventajas ofrece el uso de generics en comparación con los tipos fijos?**
   - Los generics permiten escribir código que sea más flexible y reutilizable, manteniendo la seguridad de tipos. En lugar de escribir versiones específicas para cada tipo de campo de formulario (por ejemplo, para `input`, `select`, etc.), usamos una única definición genérica que puede adaptarse a múltiples tipos de datos. Esto reduce la duplicación de código y permite un mejor mantenimiento a largo plazo, ya que los cambios en la lógica solo se deben hacer en un lugar.

---

### **Resumen de los pasos y comandos para implementar el ejercicio:**

#### 1. **Crear la carpeta `src` y el archivo `dynamic-types.ts`:**
```bash
mkdir src
touch src/dynamic-types.ts
```

#### 2. **Agregar el código en `src/dynamic-types.ts`:**

```typescript
// Definición de la interfaz FormField con generics
interface FormField<T> {
  type: 'input' | 'textarea' | 'select';
  label: string;
  value: T;
  options?: T[];
}

// Función genérica para validar campos de formulario
function validateField<T>(field: FormField<T>, inputValue: T): boolean {
  if (field.type === 'select' && field.options) {
    return field.options.includes(inputValue);
  }
  return typeof inputValue === typeof field.value;
}

// Ejemplos de campos de formulario
const nameField: FormField<string> = {
  type: 'input',
  label: 'Name',
  value: '',
};

const descriptionField: FormField<string> = {
  type: 'textarea',
  label: 'Description',
  value: '',
};

const selectField: FormField<string> = {
  type: 'select',
  label: 'Choose an option',
  value: '',
  options: ['Option 1', 'Option 2', 'Option 3'],
};

// Pruebas de validación
console.log(validateField(nameField, 'John Doe'));  // true
console.log(validateField(descriptionField, 'This is a description'));  // true
console.log(validateField(selectField, 'Option 1'));  // true
console.log(validateField(selectField, 'Invalid Option'));  // false
```

#### 3. **Compilar el código:**
```bash
npx tsc
```

#### 4. **Ejecutar el archivo compilado:**
```bash
node dist/dynamic-types.js
```

---

### **Estructura final del proyecto:**

```
generacion-tipos-dinamicos/
│
├── src/
│   └── dynamic-types.ts     # Código del ejercicio con generics y validación
│
├── dist/                    # Carpeta para archivos compilados
│   └── dynamic-types.js
│
├── tsconfig.json            # Configuración de TypeScript
└── package.json             # Proyecto Node.js
```
