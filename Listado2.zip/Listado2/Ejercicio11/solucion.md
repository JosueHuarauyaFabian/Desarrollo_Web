### **Ejercicio 11: Tipos condicionales**

#### **Descripción del problema:**
Crea una función `getResponseType` que acepte un tipo genérico `T` y devuelva un tipo basado en si `T` es una promesa. Si `T` es una `Promise`, la función debe devolver el tipo resuelto dentro de la promesa; de lo contrario, debe devolver `T` tal cual.

---

### **Solución:**

#### **Paso 1: Definir el tipo condicional**
En TypeScript, podemos usar **tipos condicionales** para verificar si un tipo cumple con una cierta condición. En este caso, podemos verificar si `T` extiende de `Promise`, y si es así, devolver el tipo que está envuelto dentro de la promesa. Si `T` no es una promesa, devolveremos `T` tal cual.

```typescript
// Tipo condicional que verifica si T es una Promise
type GetResponseType<T> = T extends Promise<infer R> ? R : T;
```

- **`T extends Promise<infer R>`**: Esta expresión verifica si `T` es una promesa. Si lo es, extrae el tipo que contiene usando `infer R`. 
- **`: R : T`**: Si `T` es una promesa, devuelve `R`, que es el tipo resuelto dentro de la promesa. Si no, simplemente devuelve `T`.

#### **Paso 2: Crear la función `getResponseType`**
A continuación, implementamos la función `getResponseType`, que usa el tipo condicional para devolver el tipo resuelto o el tipo original.

```typescript
function getResponseType<T>(input: T): GetResponseType<T> {
  if (input instanceof Promise) {
    return input.then(res => res) as GetResponseType<T>; // Si es promesa, devuelve el valor resuelto
  }
  return input as GetResponseType<T>;  // Si no es promesa, devuelve el valor tal cual
}
```

- **`getResponseType<T>(input: T): GetResponseType<T>`**: Esta función acepta un valor de tipo genérico `T`. Si `T` es una promesa, devuelve el valor resuelto; si no, devuelve el valor sin modificar.
- **`instanceof Promise`**: Verificamos si el valor de entrada es una promesa usando `instanceof`.

---

#### **Paso 3: Pruebas con diferentes tipos**
Probamos la función con valores normales y promesas para asegurarnos de que funcione correctamente con ambos casos.

```typescript
// Prueba con un valor normal (string)
const result1 = getResponseType("Hello, world!");
console.log(result1);  // "Hello, world!"

// Prueba con una promesa que resuelve un número
const result2 = getResponseType(Promise.resolve(42));
result2.then(res => console.log(res));  // 42
```

En estos ejemplos:
- **`result1`** es un string sin promesa, por lo que se devuelve tal cual.
- **`result2`** es una promesa que resuelve un número. El tipo condicional extrae el número de la promesa.

---

### **Respuestas a las preguntas de análisis:**

1. **¿Cómo pueden los tipos condicionales hacer que el código sea más adaptable y reutilizable?**
   - Los **tipos condicionales** permiten crear funciones y estructuras de datos que se adapten automáticamente a diferentes tipos. En este caso, `getResponseType` puede trabajar tanto con promesas como con valores normales, lo que lo hace más flexible y reutilizable. El tipo condicional se encarga de determinar si el valor es una promesa o no, y ajusta el comportamiento del código en consecuencia.

2. **¿Cómo manejarías un tipo que puede ser una promesa o un valor sin promesa?**
   - Para manejar un tipo que puede ser una promesa o un valor, podemos usar una combinación de **tipos condicionales** y verificaciones en tiempo de ejecución (como `instanceof Promise`). En este ejercicio, el tipo condicional `GetResponseType<T>` determina si el tipo es una promesa y extrae el tipo interno si lo es. En tiempo de ejecución, usamos `instanceof` para manejar correctamente los valores y promesas en la función.

---

### **Resumen de los pasos y comandos para implementar el ejercicio:**

#### 1. **Crear la carpeta `src` y el archivo `conditional-types.ts`:**
```bash
mkdir src
touch src/conditional-types.ts
```

#### 2. **Agregar el código en `src/conditional-types.ts`:**

```typescript
// Tipo condicional que verifica si T es una Promise
type GetResponseType<T> = T extends Promise<infer R> ? R : T;

// Función que devuelve el tipo resuelto si es una promesa, o el valor tal cual si no lo es
function getResponseType<T>(input: T): GetResponseType<T> {
  if (input instanceof Promise) {
    return input.then(res => res) as GetResponseType<T>;
  }
  return input as GetResponseType<T>;
}

// Prueba con un valor normal (string)
const result1 = getResponseType("Hello, world!");
console.log(result1);  // "Hello, world!"

// Prueba con una promesa que resuelve un número
const result2 = getResponseType(Promise.resolve(42));
result2.then(res => console.log(res));  // 42
```

#### 3. **Compilar el código:**
```bash
npx tsc
```

#### 4. **Ejecutar el archivo compilado:**
```bash
node dist/conditional-types.js
```

---

### **Estructura final del proyecto:**

```
tipos-condicionales/
│
├── src/
│   └── conditional-types.ts     # Código del ejercicio con tipos condicionales y promesas
│
├── dist/                        # Carpeta para archivos compilados
│   └── conditional-types.js
│
├── tsconfig.json                # Configuración de TypeScript
└── package.json                 # Proyecto Node.js
```
