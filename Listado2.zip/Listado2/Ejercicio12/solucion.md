### **Ejercicio 12: Mapped types y transformación de tipos**

#### **Descripción del problema:**
Implementa un sistema de caché de datos. Define un tipo genérico `Cache<T>` que convierta todas las propiedades de un objeto en `Promise<T>`. Usa este tipo para crear una caché que almacene los resultados de operaciones asíncronas y permita acceder a ellos más tarde.

---

### **Solución:**

#### **Paso 1: Definir el tipo genérico `Cache<T>`**
Un **mapped type** en TypeScript nos permite transformar todos los tipos de una estructura existente. En este caso, queremos crear un tipo `Cache<T>` que convierta todas las propiedades de un objeto `T` en `Promise<T>`.

```typescript
// Definir el tipo Cache usando mapped types
type Cache<T> = {
  [K in keyof T]: Promise<T[K]>;
};
```

- **`[K in keyof T]`**: Esto itera sobre todas las claves `K` de `T`.
- **`Promise<T[K]>`**: Convierte cada propiedad `T[K]` en una `Promise<T[K]>`, es decir, cada valor de `T` se convierte en una promesa de ese tipo.

---

#### **Paso 2: Crear una caché simulada**
Ahora creamos una clase que use este tipo `Cache<T>` para almacenar resultados de operaciones asíncronas. Esta caché almacenará los valores resueltos de las promesas.

```typescript
class AsyncCache<T> {
  private cache: Cache<T> = {} as Cache<T>;

  // Método para agregar una promesa al caché
  set<K extends keyof T>(key: K, value: T[K]): void {
    this.cache[key] = Promise.resolve(value);
  }

  // Método para obtener una promesa del caché
  get<K extends keyof T>(key: K): Promise<T[K]> {
    return this.cache[key];
  }
}
```

- **`this.cache`**: Es el almacenamiento donde guardamos promesas de los valores.
- **`set`**: Este método guarda una promesa en la caché. Convierte el valor en una promesa con `Promise.resolve()`.
- **`get`**: Este método recupera la promesa almacenada para una clave específica.

---

#### **Paso 3: Usar la caché con ejemplos**
A continuación, mostramos cómo usar la clase `AsyncCache` para almacenar resultados de operaciones asíncronas y acceder a ellos.

```typescript
// Definimos una interfaz de ejemplo
interface Data {
  name: string;
  age: number;
}

// Crear una instancia de AsyncCache para la interfaz Data
const cache = new AsyncCache<Data>();

// Guardar datos en la caché
cache.set('name', 'John Doe');
cache.set('age', 30);

// Obtener los valores de la caché
cache.get('name').then(value => console.log(value));  // John Doe
cache.get('age').then(value => console.log(value));   // 30
```

En este ejemplo:
- **`set`** agrega datos a la caché.
- **`get`** obtiene los valores de la caché. Como la caché almacena promesas, necesitamos usar `.then()` para acceder a los valores resueltos.

---

### **Respuestas a las preguntas de análisis:**

1. **¿Cómo ayuda el uso de mapped types en la reutilización de tipos complejos en sistemas web?**
   - Los **mapped types** permiten crear nuevos tipos basados en tipos existentes sin necesidad de definir cada propiedad de manera manual. Esto facilita la creación de variantes de tipos, como la conversión de todas las propiedades de un tipo en promesas (`Cache<T>` en este caso). Esto es particularmente útil en sistemas web donde muchos tipos comparten estructuras similares y se requiere transformar tipos de forma eficiente y segura.

2. **¿Qué ventajas ofrece este enfoque en la gestión de operaciones asíncronas?**
   - Al usar mapped types con promesas, se puede construir un sistema de caché que gestione fácilmente los resultados de operaciones asíncronas. Este enfoque permite acceder de manera flexible a los datos sin preocuparse de si la operación se ha completado o no, ya que las promesas garantizan que el resultado estará disponible cuando sea necesario. Además, este patrón asegura la consistencia en la estructura de los datos a lo largo de todo el sistema.

---

### **Resumen de los pasos y comandos para implementar el ejercicio:**

#### 1. **Crear la carpeta `src` y el archivo `mapped-types.ts`:**
```bash
mkdir src
touch src/mapped-types.ts
```

#### 2. **Agregar el código en `src/mapped-types.ts`:**

```typescript
// Definir el tipo Cache usando mapped types
type Cache<T> = {
  [K in keyof T]: Promise<T[K]>;
};

// Clase AsyncCache que implementa el sistema de caché
class AsyncCache<T> {
  private cache: Cache<T> = {} as Cache<T>;

  // Método para agregar una promesa al caché
  set<K extends keyof T>(key: K, value: T[K]): void {
    this.cache[key] = Promise.resolve(value);
  }

  // Método para obtener una promesa del caché
  get<K extends keyof T>(key: K): Promise<T[K]> {
    return this.cache[key];
  }
}

// Definir una interfaz de ejemplo
interface Data {
  name: string;
  age: number;
}

// Crear una instancia de AsyncCache
const cache = new AsyncCache<Data>();

// Guardar valores en la caché
cache.set('name', 'John Doe');
cache.set('age', 30);

// Obtener valores de la caché
cache.get('name').then(value => console.log(value));  // John Doe
cache.get('age').then(value => console.log(value));   // 30
```

#### 3. **Compilar el código:**
```bash
npx tsc
```

#### 4. **Ejecutar el archivo compilado:**
```bash
node dist/mapped-types.js
```

---

### **Estructura final del proyecto:**

```
mapped-types/
│
├── src/
│   └── mapped-types.ts     # Código del ejercicio con mapped types y caché
│
├── dist/                   # Carpeta para archivos compilados
│   └── mapped-types.js
│
├── tsconfig.json           # Configuración de TypeScript
└── package.json            # Proyecto Node.js
```
