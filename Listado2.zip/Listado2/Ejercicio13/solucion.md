### **Ejercicio 13: Tipos indexados**

#### **Descripción del problema:**
Crea un sistema de gestión de usuarios que tenga una estructura de datos donde los usuarios estén agrupados por roles. Define un tipo indexado `UserRoles` que acepte claves dinámicas como `admin`, `editor`, y `viewer`, y que asocie cada clave a un array de usuarios correspondientes a ese rol.

---

### **Solución:**

#### **Paso 1: Definir el tipo `UserRoles` usando tipos indexados**
Un tipo indexado en TypeScript nos permite definir un objeto donde las claves son dinámicas, pero conocemos el tipo de los valores asociados a esas claves. En este caso, usaremos tipos indexados para definir un tipo `UserRoles` donde cada clave es un rol de usuario (`admin`, `editor`, `viewer`) y el valor es un array de strings que representan los nombres de los usuarios.

```typescript
// Tipo indexado para roles de usuario
type UserRoles = {
  [role: string]: string[];  // Cada rol tendrá un array de nombres de usuario
};
```

- **`[role: string]: string[]`**: Esto indica que `UserRoles` es un objeto donde cada clave (`role`) es un string (como `admin`, `editor`, `viewer`), y el valor es un array de strings que representa los nombres de los usuarios asignados a ese rol.

---

#### **Paso 2: Crear una estructura de datos de ejemplo**
Ahora podemos crear una estructura de datos que use el tipo `UserRoles` para almacenar los usuarios agrupados por roles.

```typescript
// Ejemplo de datos de usuarios agrupados por roles
const usersByRoles: UserRoles = {
  admin: ["Alice", "Bob"],
  editor: ["Charlie", "David"],
  viewer: ["Eve", "Frank"],
};
```

En este ejemplo, tenemos tres roles:
- **`admin`**: Un array de usuarios administradores.
- **`editor`**: Un array de editores.
- **`viewer`**: Un array de espectadores.

---

#### **Paso 3: Función para agregar usuarios a un rol**
Implementamos una función para agregar un usuario a un rol específico en nuestra estructura de `UserRoles`.

```typescript
// Función para agregar un usuario a un rol específico
function addUserToRole(roles: UserRoles, role: string, user: string): void {
  if (!roles[role]) {
    roles[role] = [];  // Si el rol no existe, inicializamos el array
  }
  roles[role].push(user);  // Agregamos el usuario al array del rol
}
```

Esta función verifica si el rol ya existe en la estructura de `UserRoles`. Si no existe, inicializa un array vacío para ese rol. Luego, agrega el nombre del usuario al array correspondiente.

---

#### **Paso 4: Uso de la función con datos de ejemplo**
Ahora podemos usar la función `addUserToRole` para agregar nuevos usuarios a roles existentes o crear nuevos roles.

```typescript
// Agregar usuarios a los roles
addUserToRole(usersByRoles, "admin", "Grace");
addUserToRole(usersByRoles, "viewer", "Hank");
addUserToRole(usersByRoles, "moderator", "Ivy");  // Creación de un nuevo rol

console.log(usersByRoles);
/*
{
  admin: ["Alice", "Bob", "Grace"],
  editor: ["Charlie", "David"],
  viewer: ["Eve", "Frank", "Hank"],
  moderator: ["Ivy"]
}
*/
```

---

### **Respuestas a las preguntas de análisis:**

1. **¿Cuándo usarías tipos indexados en un proyecto web real?**
   - Los tipos indexados son útiles cuando necesitamos representar estructuras de datos dinámicas o cuando las claves de un objeto son desconocidas pero los tipos de los valores asociados son conocidos. En un proyecto web, podrías usar tipos indexados para:
     - **Gestión de usuarios**: Agrupar usuarios por roles dinámicos como en este ejemplo.
     - **Almacenamiento en caché**: Mapear claves de recursos a los datos cacheados.
     - **Configuraciones**: Representar configuraciones dinámicas donde las claves de las opciones pueden variar pero los valores son consistentes.

2. **¿Cómo afecta el uso de tipos indexados la flexibilidad del código?**
   - Los tipos indexados aumentan la flexibilidad al permitir que las claves de los objetos sean dinámicas, mientras que los valores pueden seguir siendo estrictamente tipados. Esto te permite crear estructuras de datos que se adaptan a cambios dinámicos, como agregar nuevas claves (roles de usuario en este caso), sin perder la seguridad de tipos. También facilita la adición de nuevas propiedades a los objetos sin necesidad de redefinir tipos cada vez que una nueva clave es agregada.

---

### **Resumen de los pasos y comandos para implementar el ejercicio:**

#### 1. **Crear la carpeta `src` y el archivo `indexed-types.ts`:**
```bash
mkdir src
touch src/indexed-types.ts
```

#### 2. **Agregar el código en `src/indexed-types.ts`:**

```typescript
// Definir el tipo indexado UserRoles
type UserRoles = {
  [role: string]: string[];  // Cada rol tendrá un array de nombres de usuario
};

// Ejemplo de datos de usuarios agrupados por roles
const usersByRoles: UserRoles = {
  admin: ["Alice", "Bob"],
  editor: ["Charlie", "David"],
  viewer: ["Eve", "Frank"],
};

// Función para agregar un usuario a un rol específico
function addUserToRole(roles: UserRoles, role: string, user: string): void {
  if (!roles[role]) {
    roles[role] = [];  // Si el rol no existe, inicializamos el array
  }
  roles[role].push(user);  // Agregamos el usuario al array del rol
}

// Agregar usuarios a los roles
addUserToRole(usersByRoles, "admin", "Grace");
addUserToRole(usersByRoles, "viewer", "Hank");
addUserToRole(usersByRoles, "moderator", "Ivy");  // Creación de un nuevo rol

console.log(usersByRoles);
/*
{
  admin: ["Alice", "Bob", "Grace"],
  editor: ["Charlie", "David"],
  viewer: ["Eve", "Frank", "Hank"],
  moderator: ["Ivy"]
}
*/
```

#### 3. **Compilar el código:**
```bash
npx tsc
```

#### 4. **Ejecutar el archivo compilado:**
```bash
node dist/indexed-types.js
```

---

### **Estructura final del proyecto:**

```
tipos-indexados/
│
├── src/
│   └── indexed-types.ts     # Código del ejercicio con tipos indexados
│
├── dist/                    # Carpeta para archivos compilados
│   └── indexed-types.js
│
├── tsconfig.json            # Configuración de TypeScript
└── package.json             # Proyecto Node.js
```
