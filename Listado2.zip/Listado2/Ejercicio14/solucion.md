### **Ejercicio 14: Tipos de intersección en APIs REST**

#### **Descripción del problema:**
Desarrolla un servicio REST que gestione tanto usuarios como pedidos. Crea un tipo que combine los datos de usuario (`User`) y los datos del pedido (`Order`) en un solo tipo utilizando una intersección de tipos (`&`). Usa este tipo para manejar solicitudes que necesiten acceder a ambas entidades.

---

### **Solución:**

#### **Paso 1: Definir los tipos `User` y `Order`**
Primero, necesitamos definir dos tipos principales: uno para representar a los usuarios (`User`) y otro para representar los pedidos (`Order`).

```typescript
// Tipo User que representa un usuario
interface User {
  id: number;
  name: string;
  email: string;
}

// Tipo Order que representa un pedido
interface Order {
  orderId: number;
  product: string;
  quantity: number;
}
```

- **`User`**: Representa a un usuario con un `id`, `name`, y `email`.
- **`Order`**: Representa un pedido con un `orderId`, `product`, y `quantity`.

---

#### **Paso 2: Crear la intersección de tipos `UserOrder`**
La intersección de tipos en TypeScript (`&`) nos permite combinar dos tipos en uno solo. Esto es útil cuando queremos manejar información de múltiples entidades en un solo objeto.

```typescript
// Intersección de tipos User y Order
type UserOrder = User & Order;
```

El tipo **`UserOrder`** ahora tiene todas las propiedades tanto de `User` como de `Order`.

---

#### **Paso 3: Crear una función para manejar solicitudes con `UserOrder`**
Ahora creamos una función que reciba un objeto de tipo `UserOrder` y maneje tanto la información del usuario como la del pedido.

```typescript
// Función para manejar la solicitud combinada de User y Order
function processUserOrder(userOrder: UserOrder): void {
  console.log(`Usuario: ${userOrder.name} (${userOrder.email})`);
  console.log(`Pedido: ${userOrder.product} (Cantidad: ${userOrder.quantity})`);
}
```

Esta función acepta un `UserOrder` y procesa tanto los datos del usuario como los del pedido. Accedemos a las propiedades de ambas entidades gracias a la intersección de tipos.

---

#### **Paso 4: Usar la intersección de tipos en una solicitud**
Simulamos una solicitud donde un objeto contiene tanto los datos del usuario como los del pedido, y lo pasamos a la función `processUserOrder`.

```typescript
// Ejemplo de datos combinados de usuario y pedido
const userOrderExample: UserOrder = {
  id: 1,
  name: "John Doe",
  email: "john@example.com",
  orderId: 101,
  product: "Laptop",
  quantity: 2,
};

// Procesar la solicitud con los datos combinados
processUserOrder(userOrderExample);
```

El resultado sería algo como:
```
Usuario: John Doe (john@example.com)
Pedido: Laptop (Cantidad: 2)
```

---

### **Respuestas a las preguntas de análisis:**

1. **¿Qué situaciones en una API REST justificarían el uso de intersecciones de tipos?**
   - Las intersecciones de tipos son útiles cuando una API REST necesita manejar datos de múltiples entidades en una sola solicitud. Esto puede suceder, por ejemplo:
     - En **relaciones uno a uno** entre dos entidades, como en este caso con usuarios y pedidos.
     - Cuando necesitas combinar **datos de autenticación del usuario** con detalles de la operación realizada, como la combinación de `User` y `Order` para crear un historial de transacciones.
     - Cuando tienes que **simplificar las respuestas** para evitar múltiples solicitudes a la API y enviar todos los datos relevantes en una sola respuesta.
   
2. **¿Cómo puedes asegurar la integridad de los datos cuando combinas múltiples tipos en un solo objeto?**
   - La integridad de los datos se puede asegurar mediante:
     - **Validaciones exhaustivas** antes de combinar los tipos. Puedes validar los datos de cada entidad individualmente antes de unirlos en un objeto más complejo.
     - **Validación en el servidor** utilizando bibliotecas o frameworks que aseguren que los datos cumplen con los tipos esperados.
     - **Uso de tipos condicionales o utilitarios** para manejar posibles errores en tiempo de ejecución, como la validación de datos opcionales o combinaciones que puedan estar incompletas.

---

### **Resumen de los pasos y comandos para implementar el ejercicio:**

#### 1. **Crear la carpeta `src` y el archivo `intersection-types.ts`:**
```bash
mkdir src
touch src/intersection-types.ts
```

#### 2. **Agregar el código en `src/intersection-types.ts`:**

```typescript
// Tipo User que representa un usuario
interface User {
  id: number;
  name: string;
  email: string;
}

// Tipo Order que representa un pedido
interface Order {
  orderId: number;
  product: string;
  quantity: number;
}

// Intersección de tipos User y Order
type UserOrder = User & Order;

// Función para manejar la solicitud combinada de User y Order
function processUserOrder(userOrder: UserOrder): void {
  console.log(`Usuario: ${userOrder.name} (${userOrder.email})`);
  console.log(`Pedido: ${userOrder.product} (Cantidad: ${userOrder.quantity})`);
}

// Ejemplo de datos combinados de usuario y pedido
const userOrderExample: UserOrder = {
  id: 1,
  name: "John Doe",
  email: "john@example.com",
  orderId: 101,
  product: "Laptop",
  quantity: 2,
};

// Procesar la solicitud con los datos combinados
processUserOrder(userOrderExample);
```

#### 3. **Compilar el código:**
```bash
npx tsc
```

#### 4. **Ejecutar el archivo compilado:**
```bash
node dist/intersection-types.js
```

---

### **Estructura final del proyecto:**

```
interseccion-de-tipos/
│
├── src/
│   └── intersection-types.ts     # Código del ejercicio con intersección de tipos
│
├── dist/                         # Carpeta para archivos compilados
│   └── intersection-types.js
│
├── tsconfig.json                 # Configuración de TypeScript
└── package.json                  # Proyecto Node.js
```

