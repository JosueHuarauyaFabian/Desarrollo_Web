### **Ejercicio 15: Implementación de decoradores**

#### **Descripción del problema:**
Implementa decoradores para una clase que represente un servicio de API. Crea un decorador que registre el tiempo de ejecución de cada método de la clase y otro que verifique si el usuario está autenticado antes de ejecutar el método.

---

### **Solución:**

#### **Paso 1: Crear un decorador para registrar el tiempo de ejecución**
Primero, implementamos un decorador que mida y registre el tiempo que tarda en ejecutarse un método de la clase.

```typescript
// Decorador para medir el tiempo de ejecución
function logExecutionTime(target: any, propertyKey: string, descriptor: PropertyDescriptor) {
  const originalMethod = descriptor.value;

  descriptor.value = function (...args: any[]) {
    const start = Date.now();
    const result = originalMethod.apply(this, args);
    const end = Date.now();
    console.log(`Método ${propertyKey} ejecutado en ${end - start} ms`);
    return result;
  };

  return descriptor;
}
```

- **`logExecutionTime`**: Es un decorador de método que mide el tiempo desde el inicio hasta el final de la ejecución de un método y lo registra en la consola.

---

#### **Paso 2: Crear un decorador para verificar la autenticación**
A continuación, implementamos un decorador que verifique si el usuario está autenticado antes de permitir la ejecución de un método.

```typescript
// Decorador para verificar autenticación
function checkAuthentication(target: any, propertyKey: string, descriptor: PropertyDescriptor) {
  const originalMethod = descriptor.value;

  descriptor.value = function (...args: any[]) {
    if (!this.isAuthenticated) {
      console.log("Usuario no autenticado. Acceso denegado.");
      return null;
    }
    return originalMethod.apply(this, args);
  };

  return descriptor;
}
```

- **`checkAuthentication`**: Es un decorador de método que comprueba si `isAuthenticated` es `true`. Si no lo es, bloquea la ejecución del método y registra un mensaje en la consola.

---

#### **Paso 3: Crear la clase del servicio API con los decoradores**
Definimos una clase que simule un servicio API, y aplicamos los decoradores a sus métodos.

```typescript
class ApiService {
  isAuthenticated: boolean;

  constructor(isAuthenticated: boolean) {
    this.isAuthenticated = isAuthenticated;
  }

  @logExecutionTime
  @checkAuthentication
  fetchData() {
    console.log("Datos obtenidos del servidor.");
  }

  @logExecutionTime
  @checkAuthentication
  updateData() {
    console.log("Datos actualizados en el servidor.");
  }
}
```

- **`fetchData` y `updateData`**: Ambos métodos tienen aplicados los decoradores `logExecutionTime` y `checkAuthentication`. Esto asegura que, antes de ejecutar el método, se verifique la autenticación y se registre el tiempo de ejecución.

---

#### **Paso 4: Probar la clase `ApiService`**
Creamos una instancia de la clase `ApiService` y probamos el comportamiento de los métodos con y sin autenticación.

```typescript
// Instancia con usuario autenticado
const apiServiceAuthenticated = new ApiService(true);
apiServiceAuthenticated.fetchData();  // Verificará autenticación y registrará tiempo

// Instancia con usuario no autenticado
const apiServiceNotAuthenticated = new ApiService(false);
apiServiceNotAuthenticated.updateData();  // Acceso denegado debido a la falta de autenticación
```

Resultados esperados en consola:
```
Datos obtenidos del servidor.
Método fetchData ejecutado en X ms
Usuario no autenticado. Acceso denegado.
```

---

### **Respuestas a las preguntas de análisis:**

1. **¿Qué ventajas ofrecen los decoradores para la programación orientada a aspectos en sistemas web?**
   - Los **decoradores** permiten añadir funcionalidades de manera transversal sin modificar la lógica del método o clase principal, lo que es útil en la **programación orientada a aspectos** (AOP). Esto incluye:
     - **Reutilización de código**: Permite agregar comportamientos como la autenticación, registro de logs, o manejo de errores sin duplicar código.
     - **Separación de preocupaciones**: Las funcionalidades como la medición de tiempo o verificación de permisos se manejan fuera de la lógica principal de la clase, haciendo el código más limpio y modular.

2. **¿Cómo puedes manejar la autenticación de usuarios de manera eficiente utilizando decoradores?**
   - Usar decoradores para manejar la autenticación es eficiente porque:
     - **Centraliza la lógica de autenticación**: Puedes aplicar el decorador `checkAuthentication` a todos los métodos que requieran autenticación sin tener que repetir el código.
     - **Escalabilidad**: Si necesitas cambiar la lógica de autenticación (por ejemplo, agregar soporte para tokens), solo tendrás que modificar el decorador en un lugar, en lugar de modificar cada método individual.
     - **Seguridad**: Garantiza que la autenticación siempre sea verificada antes de ejecutar cualquier método que dependa de ella.

---

### **Resumen de los pasos y comandos para implementar el ejercicio:**

#### 1. **Crear la carpeta `src` y el archivo `decorators.ts`:**
```bash
mkdir src
touch src/decorators.ts
```

#### 2. **Agregar el código en `src/decorators.ts`:**

```typescript
// Decorador para medir el tiempo de ejecución
function logExecutionTime(target: any, propertyKey: string, descriptor: PropertyDescriptor) {
  const originalMethod = descriptor.value;

  descriptor.value = function (...args: any[]) {
    const start = Date.now();
    const result = originalMethod.apply(this, args);
    const end = Date.now();
    console.log(`Método ${propertyKey} ejecutado en ${end - start} ms`);
    return result;
  };

  return descriptor;
}

// Decorador para verificar autenticación
function checkAuthentication(target: any, propertyKey: string, descriptor: PropertyDescriptor) {
  const originalMethod = descriptor.value;

  descriptor.value = function (...args: any[]) {
    if (!this.isAuthenticated) {
      console.log("Usuario no autenticado. Acceso denegado.");
      return null;
    }
    return originalMethod.apply(this, args);
  };

  return descriptor;
}

// Clase que simula un servicio API con métodos decorados
class ApiService {
  isAuthenticated: boolean;

  constructor(isAuthenticated: boolean) {
    this.isAuthenticated = isAuthenticated;
  }

  @logExecutionTime
  @checkAuthentication
  fetchData() {
    console.log("Datos obtenidos del servidor.");
  }

  @logExecutionTime
  @checkAuthentication
  updateData() {
    console.log("Datos actualizados en el servidor.");
  }
}

// Instancia con usuario autenticado
const apiServiceAuthenticated = new ApiService(true);
apiServiceAuthenticated.fetchData();  // Verificará autenticación y registrará tiempo

// Instancia con usuario no autenticado
const apiServiceNotAuthenticated = new ApiService(false);
apiServiceNotAuthenticated.updateData();  // Acceso denegado debido a la falta de autenticación
```

#### 3. **Compilar el código:**
```bash
npx tsc
```

#### 4. **Ejecutar el archivo compilado:**
```bash
node dist/decorators.js
```

---

### **Estructura final del proyecto:**

```
decoradores/
│
├── src/
│   └── decorators.ts        # Código del ejercicio con implementación de decoradores
│
├── dist/                    # Carpeta para archivos compilados
│   └── decorators.js
│
├── tsconfig.json            # Configuración de TypeScript
└── package.json             # Proyecto Node.js
```
