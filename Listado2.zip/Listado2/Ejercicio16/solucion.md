### **Ejercicio 16: Generics y constraints**

#### **Descripción del problema:**
Crea una función genérica `mergeObjects` que acepte dos objetos y los combine en uno solo. Asegúrate de que la función pueda manejar solo objetos (usa `extends` para forzar la restricción) y no otros tipos de datos como strings o arrays.

---

### **Solución:**

#### **Paso 1: Definir la función genérica con constraints**

Usaremos **generics** con **constraints** para asegurarnos de que la función solo acepte objetos y combine dos de ellos en uno solo. Para forzar que ambos parámetros sean objetos, usamos `extends` con `object`.

```typescript
// Función genérica mergeObjects que acepta solo objetos
function mergeObjects<T extends object, U extends object>(obj1: T, obj2: U): T & U {
  return { ...obj1, ...obj2 };
}
```

- **`<T extends object, U extends object>`**: Define que los tipos `T` y `U` deben ser objetos.
- **`T & U`**: Retorna un nuevo objeto que es la combinación de los dos objetos pasados como parámetros, utilizando la intersección de tipos.

---

#### **Paso 2: Probar la función con objetos válidos**

Probamos la función con dos objetos para asegurarnos de que combine correctamente sus propiedades.

```typescript
const user = { name: "John", age: 30 };
const job = { title: "Developer", salary: 5000 };

const mergedObject = mergeObjects(user, job);
console.log(mergedObject);  // { name: "John", age: 30, title: "Developer", salary: 5000 }
```

El resultado será un solo objeto que combina todas las propiedades de `user` y `job`.

---

#### **Paso 3: Probar la función con tipos inválidos**

Si intentamos usar tipos que no son objetos (como strings, números o arrays), TypeScript nos dará un error porque esos tipos no cumplen con la restricción `extends object`.

```typescript
// Esto generará un error de TypeScript
const invalidMerge = mergeObjects("Hello", { title: "Developer" });
// Error: Argument of type 'string' is not assignable to parameter of type 'object'.
```

---

### **Respuestas a las preguntas de análisis:**

1. **¿Cómo ayudan las constraints a mejorar la seguridad y flexibilidad del código en TypeScript?**
   - Las **constraints** permiten restringir los tipos que se pueden usar en una función genérica, mejorando la **seguridad de tipos** al garantizar que solo se acepten tipos válidos. Esto evita errores en tiempo de ejecución al intentar realizar operaciones en tipos no permitidos (como combinar un string con un objeto). Al mismo tiempo, mantiene la **flexibilidad** de los generics, permitiendo usar cualquier tipo de objeto sin necesidad de definir cada combinación posible.

2. **¿Qué ventajas tiene el uso de generics con constraints sobre el uso de tipos fijos?**
   - El uso de **generics con constraints** permite que la función sea más reutilizable y flexible que si se usaran tipos fijos. Por ejemplo, en lugar de escribir múltiples versiones de una función para diferentes tipos de objetos, los **generics** permiten manejar cualquier combinación de objetos. Además, las **constraints** garantizan que la función solo acepte tipos que cumplan con ciertos requisitos, manteniendo la seguridad de tipos sin sacrificar la flexibilidad.

---

### **Resumen de los pasos y comandos para implementar el ejercicio:**

#### 1. **Crear la carpeta `src` y el archivo `generics-constraints.ts`:**
```bash
mkdir src
touch src/generics-constraints.ts
```

#### 2. **Agregar el código en `src/generics-constraints.ts`:**

```typescript
// Función genérica mergeObjects que acepta solo objetos
function mergeObjects<T extends object, U extends object>(obj1: T, obj2: U): T & U {
  return { ...obj1, ...obj2 };
}

// Prueba con objetos válidos
const user = { name: "John", age: 30 };
const job = { title: "Developer", salary: 5000 };

const mergedObject = mergeObjects(user, job);
console.log(mergedObject);  // { name: "John", age: 30, title: "Developer", salary: 5000 }

// Prueba con tipos inválidos (esto generará un error)
const invalidMerge = mergeObjects("Hello", { title: "Developer" });
// Error: Argument of type 'string' is not assignable to parameter of type 'object'.
```

#### 3. **Compilar el código:**
```bash
npx tsc
```

#### 4. **Ejecutar el archivo compilado:**
```bash
node dist/generics-constraints.js
```

---

### **Estructura final del proyecto:**

```
generics-y-constraints/
│
├── src/
│   └── generics-constraints.ts     # Código del ejercicio con generics y constraints
│
├── dist/                           # Carpeta para archivos compilados
│   └── generics-constraints.js
│
├── tsconfig.json                   # Configuración de TypeScript
└── package.json                    # Proyecto Node.js
```
