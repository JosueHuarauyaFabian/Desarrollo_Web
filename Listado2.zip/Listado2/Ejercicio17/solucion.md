### **Ejercicio 17: Control de versiones con tipos**

#### **Descripción del problema:**
Imagina que estás trabajando en un sistema que necesita soportar diferentes versiones de un tipo de API. Crea dos versiones de un tipo `User` (`v1` y `v2`) y una función que acepte ambos tipos. Usa **discriminated unions** para manejar de manera segura los dos tipos de datos en la misma función.

---

### **Solución:**

#### **Paso 1: Definir las versiones del tipo `User`**

Usaremos dos versiones del tipo `User`: `UserV1` y `UserV2`. Cada una tendrá diferencias estructurales y se distinguirán mediante una propiedad discriminante, como `version`.

```typescript
// Definir la versión 1 de User
interface UserV1 {
  version: "v1";
  name: string;
  age: number;
}

// Definir la versión 2 de User
interface UserV2 {
  version: "v2";
  fullName: string;
  birthYear: number;
}
```

- **`UserV1`**: La versión original con propiedades `name` y `age`.
- **`UserV2`**: La versión nueva, que cambia `name` a `fullName` y calcula la edad usando el `birthYear`.

#### **Paso 2: Crear la discriminated union**

Una **discriminated union** es una unión de tipos que se distingue por una propiedad común, como `version` en este caso.

```typescript
// Definir el tipo User que puede ser UserV1 o UserV2
type User = UserV1 | UserV2;
```

Este tipo `User` puede ser cualquiera de las dos versiones (`v1` o `v2`).

---

#### **Paso 3: Crear una función que acepte ambas versiones**

Implementamos una función que acepte tanto `UserV1` como `UserV2` y maneje cada versión de manera adecuada usando la propiedad discriminante `version`.

```typescript
// Función para manejar ambas versiones de User
function getUserInfo(user: User): string {
  if (user.version === "v1") {
    return `User: ${user.name}, Age: ${user.age}`;
  } else {
    const age = new Date().getFullYear() - user.birthYear;
    return `User: ${user.fullName}, Age: ${age}`;
  }
}
```

- Si el usuario es de la versión 1 (`v1`), accedemos a las propiedades `name` y `age`.
- Si es de la versión 2 (`v2`), calculamos la edad utilizando `birthYear`.

#### **Paso 4: Probar la función con diferentes versiones**

Probamos la función pasando usuarios de diferentes versiones para verificar que la discriminación funcione correctamente.

```typescript
const userV1: UserV1 = { version: "v1", name: "Alice", age: 30 };
const userV2: UserV2 = { version: "v2", fullName: "Bob Johnson", birthYear: 1990 };

console.log(getUserInfo(userV1));  // User: Alice, Age: 30
console.log(getUserInfo(userV2));  // User: Bob Johnson, Age: 33 (si el año actual es 2023)
```

---

### **Respuestas a las preguntas de análisis:**

1. **¿Cómo manejas los cambios en tipos de datos entre diferentes versiones de una API?**
   - Los cambios en tipos de datos entre versiones de una API se pueden manejar usando **discriminated unions** en TypeScript, donde cada versión del tipo tiene una propiedad distintiva que permite saber cuál es la versión. Esto asegura que cada versión se maneje correctamente según su estructura de datos.

2. **¿Qué ventajas tiene el uso de discriminated unions frente a otras técnicas de manejo de múltiples versiones?**
   - Las **discriminated unions** permiten manejar múltiples versiones de manera segura y eficiente en TypeScript, ya que se basan en una propiedad común (como `version`) para decidir qué tipo es. Esto asegura que el compilador de TypeScript pueda verificar los tipos en tiempo de compilación y evitar errores en tiempo de ejecución. Además, proporciona una forma clara y estructurada de manejar cambios sin afectar la funcionalidad de versiones anteriores.

---

### **Ejercicio 18: Clases abstractas y generics**

#### **Descripción del problema:**
Crea una clase abstracta `DataService<T>` que defina métodos genéricos para obtener, actualizar y eliminar datos. Luego, implementa esta clase para un servicio de productos y un servicio de usuarios, asegurándote de que cada servicio implemente los métodos de manera específica para su tipo de dato.

---

### **Solución:**

#### **Paso 1: Crear la clase abstracta `DataService<T>`**

Definimos una clase abstracta genérica que tendrá métodos para las operaciones básicas (`get`, `update`, y `delete`), pero no implementará estos métodos. Las clases que hereden de `DataService<T>` deberán implementar estos métodos.

```typescript
// Clase abstracta DataService
abstract class DataService<T> {
  abstract get(id: number): T;
  abstract update(id: number, data: T): void;
  abstract delete(id: number): void;
}
```

#### **Paso 2: Implementar el servicio de productos**

Creamos una clase `ProductService` que hereda de `DataService<Product>`, donde `Product` es el tipo de datos manejado.

```typescript
// Tipo Product
interface Product {
  id: number;
  name: string;
  price: number;
}

// Implementación de ProductService
class ProductService extends DataService<Product> {
  private products: Product[] = [];

  get(id: number): Product {
    return this.products.find(product => product.id === id)!;
  }

  update(id: number, data: Product): void {
    const index = this.products.findIndex(product => product.id === id);
    if (index !== -1) {
      this.products[index] = data;
    }
  }

  delete(id: number): void {
    this.products = this.products.filter(product => product.id !== id);
  }
}
```

- **`ProductService`** implementa los métodos de `DataService<Product>` para manejar productos.

#### **Paso 3: Implementar el servicio de usuarios**

De manera similar, creamos una clase `UserService` para manejar usuarios.

```typescript
// Tipo User
interface User {
  id: number;
  name: string;
  email: string;
}

// Implementación de UserService
class UserService extends DataService<User> {
  private users: User[] = [];

  get(id: number): User {
    return this.users.find(user => user.id === id)!;
  }

  update(id: number, data: User): void {
    const index = this.users.findIndex(user => user.id === id);
    if (index !== -1) {
      this.users[index] = data;
    }
  }

  delete(id: number): void {
    this.users = this.users.filter(user => user.id !== id);
  }
}
```

---

### **Respuestas a las preguntas de análisis:**

1. **¿Qué beneficios aporta el uso de clases abstractas en combinación con generics en TypeScript?**
   - Las **clases abstractas** permiten definir una estructura común que otras clases pueden reutilizar, lo que promueve la reutilización del código. Cuando se combinan con **generics**, estas clases abstractas pueden manejar diferentes tipos de datos de manera flexible, permitiendo que la misma clase base maneje productos, usuarios u otros tipos, sin necesidad de escribir múltiples versiones del mismo código.

2. **¿Cómo puedes aplicar este patrón a un sistema de microservicios?**
   - En un sistema de **microservicios**, podrías usar clases abstractas y genéricas para definir servicios comunes (como `DataService`) que manejen la obtención, actualización y eliminación de datos en todos los microservicios. Cada microservicio implementaría su propia versión del servicio según el tipo de datos que maneje (productos, usuarios, pedidos, etc.), asegurando una arquitectura modular y fácil de mantener.

