### **Ejercicio 2: Tipos simples y funciones tipadas**

#### **Descripción del problema:**
Desarrolla una API REST simulada donde definas funciones que acepten y devuelvan tipos específicos. Define un tipo que represente a un usuario y una función que acepte este tipo como argumento. Además, implementa una función que devuelva un array de usuarios filtrados según ciertos criterios.

---

### **Solución:**

#### Paso 1: Definir el tipo de datos de usuario
Lo primero es definir un tipo o una interfaz que represente a un usuario en TypeScript.

```typescript
type User = {
  id: number;
  name: string;
  age: number;
  isAdmin: boolean;
};
```

En este caso, un `User` tiene cuatro propiedades: un identificador (`id`), un nombre (`name`), una edad (`age`) y una propiedad booleana que indica si es administrador o no (`isAdmin`).

#### Paso 2: Función que acepte un usuario como argumento
Ahora crearemos una función que reciba un objeto de tipo `User` y que realice una operación simple, como imprimir sus detalles en la consola.

```typescript
function printUserDetails(user: User): void {
  console.log(`ID: ${user.id}, Name: ${user.name}, Age: ${user.age}, Admin: ${user.isAdmin}`);
}
```

#### Paso 3: Función que filtre usuarios según un criterio
La siguiente función recibe un array de usuarios y filtra solo aquellos que cumplan con un criterio específico, en este caso, que sean administradores.

```typescript
function filterAdmins(users: User[]): User[] {
  return users.filter(user => user.isAdmin);
}
```

#### Paso 4: Simular la API con una lista de usuarios
Podemos simular una base de datos de usuarios creando un array de objetos de tipo `User` y luego utilizando nuestras funciones sobre estos datos.

```typescript
const users: User[] = [
  { id: 1, name: 'Alice', age: 25, isAdmin: true },
  { id: 2, name: 'Bob', age: 22, isAdmin: false },
  { id: 3, name: 'Charlie', age: 30, isAdmin: true },
  { id: 4, name: 'David', age: 28, isAdmin: false }
];

// Imprimir detalles de cada usuario
users.forEach(printUserDetails);

// Filtrar administradores
const admins = filterAdmins(users);
console.log("Administradores: ", admins);
```

---

### **Respuestas a las preguntas de análisis:**

1. **¿Qué beneficios aporta definir tipos explícitos en las funciones?**
   - **Claridad**: Definir tipos explícitos hace que el código sea más claro, ya que describe exactamente qué tipo de datos se espera y qué se devolverá. Esto es especialmente útil cuando otros desarrolladores trabajan con el mismo código.
   - **Seguridad**: TypeScript ayuda a detectar errores en tiempo de compilación. Al definir tipos explícitos, evitamos errores comunes como el acceso a propiedades que no existen o pasar valores de tipos incorrectos.
   - **Autocompletado**: Los editores de código como VSCode pueden ofrecer autocompletado más preciso y útil cuando las funciones y las variables están correctamente tipadas.

2. **¿Cómo manejas los posibles errores de tipo al manipular datos?**
   - TypeScript ayuda a prevenir errores de tipo con su verificación en tiempo de compilación. Sin embargo, para manejar errores inesperados, se pueden usar técnicas como:
     - **Validaciones de tipo**: Antes de procesar datos, puedes verificar su tipo usando `typeof` o asegurarte de que las propiedades necesarias estén presentes.
     - **Try-Catch**: Para capturar errores en la ejecución de código que manipula datos externos (por ejemplo, datos provenientes de una API).
     - **Definición estricta de tipos**: Siempre declarar y utilizar tipos estrictos reduce la posibilidad de errores.

---

### **Resumen de los pasos y comandos para implementar el ejercicio:**

1. **Define el tipo `User`:**
   ```typescript
   type User = {
     id: number;
     name: string;
     age: number;
     isAdmin: boolean;
   };
   ```

2. **Crea la función `printUserDetails`:**
   ```typescript
   function printUserDetails(user: User): void {
     console.log(`ID: ${user.id}, Name: ${user.name}, Age: ${user.age}, Admin: ${user.isAdmin}`);
   }
   ```

3. **Crea la función `filterAdmins`:**
   ```typescript
   function filterAdmins(users: User[]): User[] {
     return users.filter(user => user.isAdmin);
   }
   ```

4. **Simula un array de usuarios y utiliza las funciones:**
   ```typescript
   const users: User[] = [
     { id: 1, name: 'Alice', age: 25, isAdmin: true },
     { id: 2, name: 'Bob', age: 22, isAdmin: false },
     { id: 3, name: 'Charlie', age: 30, isAdmin: true },
     { id: 4, name: 'David', age: 28, isAdmin: false }
   ];

   // Imprimir detalles de cada usuario
   users.forEach(printUserDetails);

   // Filtrar administradores
   const admins = filterAdmins(users);
   console.log("Administradores: ", admins);
   ```

### **Resumen de comandos utilizados**

1. **Inicialización del proyecto TypeScript**
   - Crea la carpeta del proyecto y navega dentro de ella:
     ```bash
     mkdir api-usuarios-typescript
     cd api-usuarios-typescript
     ```

2. **Inicialización del proyecto Node.js**
   - Inicializa un proyecto básico de Node.js con `package.json`:
     ```bash
     npm init -y
     ```

3. **Instalación de TypeScript**
   - Instala TypeScript como dependencia de desarrollo:
     ```bash
     npm install typescript --save-dev
     ```

4. **Crear archivo de configuración `tsconfig.json`**
   - Inicializa el archivo de configuración de TypeScript:
     ```bash
     npx tsc --init
     ```

5. **Modificación del archivo `tsconfig.json`**
   - Asegúrate de que la configuración tenga una carpeta de salida para los archivos compilados. Edita tu archivo `tsconfig.json` para agregar o modificar la opción `outDir`:
   
   ```json
   {
     "compilerOptions": {
       "target": "es2016",
       "module": "commonjs",
       "outDir": "./dist",             /* Especifica una carpeta de salida para todos los archivos compilados */
       "esModuleInterop": true,
       "forceConsistentCasingInFileNames": true,
       "strict": true,
       "skipLibCheck": true
     }
   }
   ```

6. **Crear los archivos `.ts`**
   - Crea una carpeta `src` para almacenar los archivos fuente TypeScript:
     ```bash
     mkdir src
     ```
   
   - Crea los archivos necesarios dentro de `src`:
     - `user.ts`: Define tipos y funciones
     ```bash
     touch src/user.ts
     ```
     - `index.ts`: Archivo principal que utiliza las funciones
     ```bash
     touch src/index.ts
     ```

7. **Compilar el código TypeScript**
   - Compila todos los archivos TypeScript en el proyecto:
     ```bash
     npx tsc
     ```

8. **Ejecutar el código compilado**
   - Ejecuta el archivo compilado de JavaScript dentro de la carpeta `dist`:
     ```bash
     node dist/index.js
     ```

---

### **Modificaciones realizadas**

1. **Modificación del archivo `tsconfig.json`:**
   - Agregaste la opción `outDir: "./dist"` para especificar que los archivos compilados se generen en una carpeta separada llamada `dist`.
   
2. **Creación de los archivos `.ts`:**
   - **`src/user.ts`:**
     Definiste los tipos de datos `User` y las funciones `printUserDetails` y `filterAdmins` para gestionar los usuarios.
   - **`src/index.ts`:**
     Implementaste la lógica principal que imprime los detalles de los usuarios y filtra a los administradores, utilizando las funciones definidas en `user.ts`.

3. **Compilación del proyecto:**
   - Se ejecutó `npx tsc` para compilar los archivos TypeScript en JavaScript, generando los archivos compilados en la carpeta `dist`.

4. **Ejecución del proyecto:**
   - Finalmente, se ejecutó el archivo `index.js` compilado dentro de la carpeta `dist`.

---

### **Flujo completo para la prueba**

1. Crear carpeta del proyecto.
2. Inicializar `npm` y `tsconfig.json`.
3. Crear los archivos `.ts` en la carpeta `src`.
4. Configurar `outDir` en `tsconfig.json` para que los archivos compilados se guarden en `dist`.
5. Compilar el proyecto con `npx tsc`.
6. Ejecutar el archivo compilado con `node dist/index.js`.

