"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const user_1 = require("./user");
// Lista de usuarios simulada
const users = [
    { id: 1, name: 'Alice', age: 25, isAdmin: true },
    { id: 2, name: 'Bob', age: 22, isAdmin: false },
    { id: 3, name: 'Charlie', age: 30, isAdmin: true },
    { id: 4, name: 'David', age: 28, isAdmin: false }
];
// Imprimir detalles de cada usuario
users.forEach(user_1.printUserDetails);
// Filtrar y mostrar administradores
const admins = (0, user_1.filterAdmins)(users);
console.log("Administradores: ", admins);
