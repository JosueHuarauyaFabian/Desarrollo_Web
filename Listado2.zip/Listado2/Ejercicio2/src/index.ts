import { User, printUserDetails, filterAdmins } from './user';

// Lista de usuarios simulada
const users: User[] = [
  { id: 1, name: 'Alice', age: 25, isAdmin: true },
  { id: 2, name: 'Bob', age: 22, isAdmin: false },
  { id: 3, name: 'Charlie', age: 30, isAdmin: true },
  { id: 4, name: 'David', age: 28, isAdmin: false }
];

// Imprimir detalles de cada usuario
users.forEach(printUserDetails);

// Filtrar y mostrar administradores
const admins = filterAdmins(users);
console.log("Administradores: ", admins);
