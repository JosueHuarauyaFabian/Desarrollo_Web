"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.printUserDetails = printUserDetails;
exports.filterAdmins = filterAdmins;
// Función para imprimir detalles de usuario
function printUserDetails(user) {
    console.log(`ID: ${user.id}, Name: ${user.name}, Age: ${user.age}, Admin: ${user.isAdmin}`);
}
// Función para filtrar usuarios administradores
function filterAdmins(users) {
    return users.filter(user => user.isAdmin);
}
