// Tipo User
export type User = {
    id: number;
    name: string;
    age: number;
    isAdmin: boolean;
  };
  
  // Función para imprimir detalles de usuario
  export function printUserDetails(user: User): void {
    console.log(`ID: ${user.id}, Name: ${user.name}, Age: ${user.age}, Admin: ${user.isAdmin}`);
  }
  
  // Función para filtrar usuarios administradores
  export function filterAdmins(users: User[]): User[] {
    return users.filter(user => user.isAdmin);
  }
  