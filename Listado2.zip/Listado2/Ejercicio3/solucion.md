### **Ejercicio 3: Interfaces y herencia de interfaces**

#### **Requisitos:**
1. Definir una interfaz `Task` con propiedades como `title`, `description`, y `status`.
2. Extender la interfaz `Task` creando una nueva interfaz `CompletedTask`, que tendrá una propiedad adicional llamada `completionDate`.
3. Crear una función que acepte tanto tareas regulares (`Task`) como tareas completadas (`CompletedTask`), y que maneje ambos tipos correctamente.

---

### **Solución:**

#### Paso 1: Definir la interfaz `Task`
Comencemos definiendo la interfaz `Task`, que contendrá las propiedades mencionadas.

```typescript
interface Task {
  title: string;
  description: string;
  status: 'pending' | 'in-progress' | 'completed';
}
```

Esta interfaz representa una tarea que tiene un título (`title`), una descripción (`description`) y un estado (`status`). El estado puede ser `'pending'`, `'in-progress'` o `'completed'`.

#### Paso 2: Extender la interfaz `Task` con `CompletedTask`
A continuación, extendemos la interfaz `Task` para crear la interfaz `CompletedTask`, que tendrá una propiedad adicional `completionDate` para registrar la fecha en que la tarea fue completada.

```typescript
interface CompletedTask extends Task {
  completionDate: Date;
}
```

Aquí `CompletedTask` hereda todas las propiedades de `Task` y agrega la propiedad `completionDate`.

#### Paso 3: Crear una función que maneje ambos tipos
Ahora, creamos una función que acepte tanto tareas de tipo `Task` como tareas de tipo `CompletedTask`. Esta función podría, por ejemplo, imprimir información sobre la tarea y, si es una tarea completada, también mostrar la fecha de finalización.

```typescript
function displayTask(task: Task | CompletedTask): void {
  console.log(`Title: ${task.title}`);
  console.log(`Description: ${task.description}`);
  console.log(`Status: ${task.status}`);

  if (task.status === 'completed' && 'completionDate' in task) {
    console.log(`Completed on: ${task.completionDate}`);
  }
}
```

Esta función utiliza `task: Task | CompletedTask` para aceptar tanto tareas regulares como tareas completadas. Además, verifica si la tarea está en estado `completed` y si tiene la propiedad `completionDate` para mostrarla.

#### Paso 4: Probar la función con ejemplos
Ahora, podemos crear ejemplos de tareas regulares y tareas completadas, y probar la función `displayTask`.

```typescript
const task1: Task = {
  title: 'Write report',
  description: 'Write the monthly report for the team',
  status: 'in-progress',
};

const task2: CompletedTask = {
  title: 'Finish project',
  description: 'Complete the final project for the client',
  status: 'completed',
  completionDate: new Date('2024-09-30'),
};

displayTask(task1);
displayTask(task2);
```

---

### **Respuestas a las preguntas de análisis:**

1. **¿Cómo decidirías cuándo usar interfaces y cuándo usar clases en TypeScript?**
   - **Interfaces**: Son útiles cuando quieres definir la estructura de un objeto sin necesidad de implementar lógica o comportamiento. Usarías interfaces para definir contratos entre partes del código, permitiendo mayor flexibilidad al definir solo las propiedades y métodos que un objeto debe tener.
   - **Clases**: Son más adecuadas cuando necesitas una implementación concreta con lógica. Las clases permiten definir tanto la estructura como el comportamiento de los objetos, y pueden incluir métodos y control sobre la inicialización de las propiedades. Las clases también son útiles cuando necesitas aprovechar características como herencia y polimorfismo.

2. **¿Qué ventajas ofrece la herencia de interfaces en comparación con la herencia de clases?**
   - **Herencia de interfaces**: Te permite combinar estructuras de objetos sin forzar la implementación de ningún comportamiento. Es más flexible, ya que solo define el "contrato" que los objetos deben seguir. Esto es útil cuando diferentes objetos comparten algunas propiedades, pero pueden tener implementaciones completamente distintas.
   - **Herencia de clases**: Además de heredar estructura, también hereda comportamiento, lo que puede ser útil cuando varios objetos deben compartir la misma lógica. Sin embargo, es menos flexible que la herencia de interfaces, ya que impone una implementación y puede ser más difícil de modificar o adaptar en casos donde se necesita más flexibilidad.

---

### **Resumen de los pasos y comandos para implementar el ejercicio:**

1. **Define la interfaz `Task`:**
   ```typescript
   interface Task {
     title: string;
     description: string;
     status: 'pending' | 'in-progress' | 'completed';
   }
   ```

2. **Extiende la interfaz `Task` con `CompletedTask`:**
   ```typescript
   interface CompletedTask extends Task {
     completionDate: Date;
   }
   ```

3. **Crea la función `displayTask`:**
   ```typescript
   function displayTask(task: Task | CompletedTask): void {
     console.log(`Title: ${task.title}`);
     console.log(`Description: ${task.description}`);
     console.log(`Status: ${task.status}`);

     if (task.status === 'completed' && 'completionDate' in task) {
       console.log(`Completed on: ${task.completionDate}`);
     }
   }
   ```

4. **Prueba la función con ejemplos:**
   ```typescript
   const task1: Task = {
     title: 'Write report',
     description: 'Write the monthly report for the team',
     status: 'in-progress',
   };

   const task2: CompletedTask = {
     title: 'Finish project',
     description: 'Complete the final project for the client',
     status: 'completed',
     completionDate: new Date('2024-09-30'),
   };

   displayTask(task1);
   displayTask(task2);
   ```

### **Pasos para completar el ejercicio:**

### 1. **Inicialización del proyecto TypeScript**
Si ya tienes un proyecto de TypeScript configurado, puedes saltarte esta parte. De lo contrario, sigue estos pasos.

#### a. Crea una carpeta para el proyecto:
```bash
mkdir gestion-tareas-typescript
cd gestion-tareas-typescript
```

#### b. Inicializa un proyecto Node.js:
```bash
npm init -y
```

#### c. Instala TypeScript:
```bash
npm install typescript --save-dev
```

#### d. Crea el archivo de configuración `tsconfig.json`:
```bash
npx tsc --init
```

#### e. Configura la carpeta de salida en el `tsconfig.json`:
Abre el archivo `tsconfig.json` y asegúrate de agregar o descomentar la opción `outDir`:

```json
{
  "compilerOptions": {
    "target": "es2016",
    "module": "commonjs",
    "outDir": "./dist",
    "esModuleInterop": true,
    "strict": true,
    "skipLibCheck": true
  }
}
```

Esto garantizará que los archivos compilados se generen en la carpeta `dist`.

---

### 2. **Creación de los archivos TypeScript**

#### a. **Crear la carpeta `src` para almacenar los archivos fuente**:
```bash
mkdir src
```

#### b. **Crear los archivos `.ts`**:
1. **`task.ts`:** Define las interfaces `Task` y `CompletedTask`.

   - Crea el archivo:
     ```bash
     touch src/task.ts
     ```

   - Añade el siguiente código en `src/task.ts`:
     ```typescript
     // src/task.ts

     export interface Task {
       title: string;
       description: string;
       status: 'pending' | 'in-progress' | 'completed';
     }

     export interface CompletedTask extends Task {
       completionDate: Date;
     }
     ```

2. **`index.ts`:** Implementa la función `displayTask` que acepta tanto tareas regulares como tareas completadas y prueba la función.

   - Crea el archivo:
     ```bash
     touch src/index.ts
     ```

   - Añade el siguiente código en `src/index.ts`:
     ```typescript
     // src/index.ts
     import { Task, CompletedTask } from './task';

     function displayTask(task: Task | CompletedTask): void {
       console.log(`Title: ${task.title}`);
       console.log(`Description: ${task.description}`);
       console.log(`Status: ${task.status}`);

       if (task.status === 'completed' && 'completionDate' in task) {
         console.log(`Completed on: ${task.completionDate}`);
       }
     }

     const task1: Task = {
       title: 'Write report',
       description: 'Write the monthly report for the team',
       status: 'in-progress',
     };

     const task2: CompletedTask = {
       title: 'Finish project',
       description: 'Complete the final project for the client',
       status: 'completed',
       completionDate: new Date('2024-09-30'),
     };

     displayTask(task1);
     displayTask(task2);
     ```

---

### 3. **Compilar y ejecutar el proyecto**

#### a. **Compilar el proyecto TypeScript**:
Este comando compilará todos los archivos `.ts` en archivos `.js` dentro de la carpeta `dist`.

```bash
npx tsc
```

#### b. **Ejecutar el archivo compilado**:
Una vez que se haya compilado el código, ejecuta el archivo JavaScript compilado que se encuentra en la carpeta `dist`.

```bash
node dist/index.js
```

---

### **Resumen de Comandos**

1. Crear la carpeta del proyecto y navegar dentro de ella:
   ```bash
   mkdir gestion-tareas-typescript
   cd gestion-tareas-typescript
   ```

2. Inicializar un proyecto de Node.js:
   ```bash
   npm init -y
   ```

3. Instalar TypeScript:
   ```bash
   npm install typescript --save-dev
   ```

4. Crear el archivo de configuración `tsconfig.json`:
   ```bash
   npx tsc --init
   ```

5. Crear la carpeta `src` para almacenar los archivos fuente:
   ```bash
   mkdir src
   ```

6. Crear los archivos `.ts`:
   - `touch src/task.ts`
   - `touch src/index.ts`

7. Compilar el código TypeScript:
   ```bash
   npx tsc
   ```

8. Ejecutar el archivo compilado:
   ```bash
   node dist/index.js
   ```

---

### **Estructura final del proyecto:**

El proyecto tendrá la siguiente estructura:

```
gestion-tareas-typescript/
│
├── src/
│   ├── task.ts            # Definición de interfaces Task y CompletedTask
│   └── index.ts           # Implementación de la función displayTask
│
├── dist/                  # Carpeta donde se compilará el código JavaScript
│   ├── task.js
│   └── index.js
│
├── tsconfig.json          # Configuración de TypeScript
└── package.json           # Proyecto Node.js
```
