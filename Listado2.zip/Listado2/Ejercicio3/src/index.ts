import { Task, CompletedTask } from './task';

function displayTask(task: Task | CompletedTask): void {
  console.log(`Title: ${task.title}`);
  console.log(`Description: ${task.description}`);
  console.log(`Status: ${task.status}`);

  if (task.status === 'completed' && 'completionDate' in task) {
    console.log(`Completed on: ${task.completionDate}`);
  }
}

const task1: Task = {
  title: 'Write report',
  description: 'Write the monthly report for the team',
  status: 'in-progress',
};

const task2: CompletedTask = {
  title: 'Finish project',
  description: 'Complete the final project for the client',
  status: 'completed',
  completionDate: new Date('2024-09-30'),
};

displayTask(task1);
displayTask(task2);
