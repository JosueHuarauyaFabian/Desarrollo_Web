export interface Task {
    title: string;
    description: string;
    status: 'pending' | 'in-progress' | 'completed';
  }
  
  export interface CompletedTask extends Task {
    completionDate: Date;
  }
  