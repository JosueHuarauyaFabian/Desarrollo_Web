### **Ejercicio 4: Narrowing y null types**

#### **Objetivo:**
- Aplicar **narrowing** para trabajar con tipos que pueden ser múltiples valores (`string`, `number`, etc.).
- Manejar valores `null` y `undefined` de manera segura en el código.

#### **Requisitos:**
1. Desarrollar una función que acepte un argumento que pueda ser de tipo `string` o `number`.
2. Usar técnicas de **narrowing** para procesar el argumento dependiendo de su tipo.
3. Asegurarse de manejar valores `null` o `undefined` en el argumento.

---

### **Solución:**

#### Paso 1: Crear la función con tipos combinados
Comienza definiendo una función que acepte un argumento que pueda ser de tipo `string`, `number`, `null` o `undefined`. El operador de unión (`|`) permite que un parámetro acepte varios tipos:

```typescript
function processValue(value: string | number | null | undefined): string {
  // Narrowing: verifica si el valor es null o undefined
  if (value === null) {
    return "Valor es null";
  } else if (value === undefined) {
    return "Valor es undefined";
  }

  // Narrowing: verifica si el valor es un string
  if (typeof value === 'string') {
    return `Valor es un string: ${value.toUpperCase()}`;
  }

  // Narrowing: verifica si el valor es un número
  if (typeof value === 'number') {
    return `Valor es un número: ${value * 2}`;
  }

  // Caso predeterminado (aunque no debería llegar aquí debido al narrowing anterior)
  return "Valor desconocido";
}
```

### **Explicación del Narrowing:**
- **`typeof value === 'string'`:** Verifica si el valor es de tipo `string` y luego realiza una operación, como convertir el string a mayúsculas.
- **`typeof value === 'number'`:** Verifica si el valor es un número y luego realiza una operación aritmética, como multiplicar el valor por 2.
- **Verificación de `null` y `undefined`:** El primer `if` se asegura de que `null` y `undefined` se manejen de manera explícita, devolviendo un mensaje diferente.

---

### **Prueba de la función con diferentes valores:**

```typescript
console.log(processValue("hola"));      // "Valor es un string: HOLA"
console.log(processValue(10));          // "Valor es un número: 20"
console.log(processValue(null));        // "Valor es null"
console.log(processValue(undefined));   // "Valor es undefined"
```

### **Respuestas a las preguntas:**

1. **¿Qué diferencia hay entre `null` y `undefined` en TypeScript?**
   - **`null`**: Representa un valor explícitamente vacío o "ausente". Se utiliza cuando intencionalmente queremos indicar que una variable no tiene valor.
   - **`undefined`**: Significa que una variable ha sido declarada pero no tiene asignado un valor. También es el valor por defecto de las variables que no han sido inicializadas.
   
   En TypeScript, ambos pueden ser manejados, pero `undefined` generalmente indica un error o falta de inicialización, mientras que `null` puede ser usado de manera más intencionada.

2. **¿Cómo afecta el uso de narrowing a la seguridad del código?**
   El uso de **narrowing** mejora significativamente la seguridad del código al reducir el conjunto de tipos con los que se trabaja en diferentes bloques de código. Esto garantiza que se manejen correctamente todos los casos posibles y se minimicen errores de tipo en tiempo de ejecución. Por ejemplo:
   - Al usar `typeof` o verificaciones directas para `null` y `undefined`, aseguramos que los valores sean procesados adecuadamente según su tipo.
   - Evita errores al intentar realizar operaciones sobre tipos incompatibles (como intentar usar un método de `string` en un número).

### **Resumen de los pasos y comandos:**

#### a. **Crear el archivo `narrowing.ts`:**
   ```bash
   touch src/narrowing.ts
   ```

#### b. **Agregar el código de la función `processValue` en `narrowing.ts`:**
   ```typescript
   function processValue(value: string | number | null | undefined): string {
     if (value === null) {
       return "Valor es null";
     } else if (value === undefined) {
       return "Valor es undefined";
     }

     if (typeof value === 'string') {
       return `Valor es un string: ${value.toUpperCase()}`;
     }

     if (typeof value === 'number') {
       return `Valor es un número: ${value * 2}`;
     }

     return "Valor desconocido";
   }

   // Pruebas
   console.log(processValue("hola"));      // "Valor es un string: HOLA"
   console.log(processValue(10));          // "Valor es un número: 20"
   console.log(processValue(null));        // "Valor es null"
   console.log(processValue(undefined));   // "Valor es undefined"
   ```

#### c. **Compilar y ejecutar el archivo:**
   - Compilar el archivo:
     ```bash
     npx tsc
     ```
   - Ejecutar el archivo compilado:
     ```bash
     node dist/narrowing.js
     ```

### **Pasos para completar el ejercicio 4:**

#### 1. **Inicialización del proyecto TypeScript (si no lo tienes aún)**

Si ya tienes un proyecto configurado, puedes saltar esta parte. Si no, sigue estos pasos.

```bash
mkdir ejercicio-narrowing-null-types  # Crea una carpeta para el proyecto
cd ejercicio-narrowing-null-types     # Entra en la carpeta
npm init -y                          # Inicializa el proyecto Node.js
npm install typescript --save-dev    # Instala TypeScript como dependencia de desarrollo
npx tsc --init                       # Genera el archivo de configuración tsconfig.json
```

---

#### 2. **Configurar el archivo `tsconfig.json` (opcional)**

Si quieres que los archivos compilados se guarden en una carpeta separada (ej: `dist`), abre tu archivo `tsconfig.json` y agrega o descomenta la siguiente línea en `compilerOptions`:

```json
{
  "compilerOptions": {
    "outDir": "./dist"  // Carpeta donde se almacenarán los archivos compilados
  }
}
```

---

#### 3. **Crear los archivos TypeScript**

Vamos a crear el archivo `narrowing.ts` donde escribirás el código del ejercicio.

```bash
mkdir src                 # Crea la carpeta 'src' para los archivos fuente
touch src/narrowing.ts     # Crea el archivo TypeScript 'narrowing.ts'
```

---

#### 4. **Código comentado línea por línea**

Agrega el siguiente código en el archivo `src/narrowing.ts` y cada línea está explicada con un comentario.

```typescript
// Definimos la función `processValue` que acepta un argumento que puede ser de tipo
// string, number, null o undefined. Usamos el operador de unión (|) para aceptar múltiples tipos.
function processValue(value: string | number | null | undefined): string {
  
  // Verificamos si el valor es `null`.
  if (value === null) {
    // Retornamos un mensaje indicando que el valor es null.
    return "Valor es null";
  } 

  // Verificamos si el valor es `undefined`.
  else if (value === undefined) {
    // Retornamos un mensaje indicando que el valor es undefined.
    return "Valor es undefined";
  }

  // Usamos `typeof` para verificar si el valor es un string.
  if (typeof value === 'string') {
    // Si es un string, retornamos el valor en mayúsculas.
    return `Valor es un string: ${value.toUpperCase()}`;
  }

  // Usamos `typeof` para verificar si el valor es un número.
  if (typeof value === 'number') {
    // Si es un número, retornamos el valor multiplicado por 2.
    return `Valor es un número: ${value * 2}`;
  }

  // En caso de que ninguna de las verificaciones anteriores se cumpla,
  // retornamos un mensaje predeterminado (aunque este caso no debería ocurrir).
  return "Valor desconocido";
}

// Ahora probamos la función con diferentes valores:

// Prueba con un string
console.log(processValue("hola"));  // Esperado: "Valor es un string: HOLA"

// Prueba con un número
console.log(processValue(10));      // Esperado: "Valor es un número: 20"

// Prueba con null
console.log(processValue(null));    // Esperado: "Valor es null"

// Prueba con undefined
console.log(processValue(undefined)); // Esperado: "Valor es undefined"
```

### **Explicación del código:**

1. **Función `processValue`:**
   - Acepta un argumento que puede ser `string`, `number`, `null`, o `undefined`.
   - Usa **narrowing** (reducción de tipos) para identificar el tipo del argumento y procesarlo de manera diferente según el tipo.
   
2. **Verificaciones con `null` y `undefined`:**
   - Primero verificamos si el valor es `null` o `undefined` y retornamos un mensaje específico para cada caso.
   
3. **Narrowing con `typeof`:**
   - Usamos `typeof` para verificar si el valor es un `string` o un `number`.
   - Si es `string`, lo convertimos a mayúsculas con `toUpperCase()`.
   - Si es `number`, lo multiplicamos por 2.

4. **Pruebas de la función:**
   - Probamos la función con valores de ejemplo: `string`, `number`, `null`, y `undefined`.

---

#### 5. **Compilar y ejecutar el código**

Después de haber escrito el código en `narrowing.ts`, sigue estos pasos para compilar y ejecutar el archivo:

1. **Compilar el archivo TypeScript**:
   - Este comando compila todos los archivos `.ts` en la carpeta `src` y genera los archivos `.js` en la carpeta `dist`.
   ```bash
   npx tsc
   ```

2. **Ejecutar el archivo compilado**:
   - Ahora ejecuta el archivo JavaScript compilado que está en la carpeta `dist`.
   ```bash
   node dist/narrowing.js
   ```

---

### **Resumen de los comandos utilizados:**

1. **Inicialización del proyecto:**
   ```bash
   mkdir ejercicio-narrowing-null-types
   cd ejercicio-narrowing-null-types
   npm init -y
   npm install typescript --save-dev
   npx tsc --init
   ```

2. **Crear la carpeta `src` y el archivo `narrowing.ts`:**
   ```bash
   mkdir src
   touch src/narrowing.ts
   ```

3. **Compilar el proyecto:**
   ```bash
   npx tsc
   ```

4. **Ejecutar el archivo compilado:**
   ```bash
   node dist/narrowing.js
   ```
