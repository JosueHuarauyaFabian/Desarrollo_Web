### **Ejercicio 5: Utility types y creación de tipos a partir de otros**

#### **Descripción del problema:**
Crea un sistema de gestión de productos para una tienda en línea. Define una interfaz `Product` con varias propiedades. Utiliza los tipos utilitarios como `Partial` y `Pick` para crear nuevas versiones del tipo `Product`, como:
- Una versión parcial del producto para editar.
- Una versión más limitada que solo incluya el nombre y el precio.

---

### **Solución:**

#### Paso 1: Definir la interfaz `Product`
Vamos a crear la interfaz `Product` con varias propiedades que describen un producto en la tienda en línea.

```typescript
interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
  category: string;
  stock: number;
}
```

Esta interfaz tiene varias propiedades: 
- `id`: identificador único del producto.
- `name`: nombre del producto.
- `price`: precio del producto.
- `description`: descripción del producto.
- `category`: categoría del producto.
- `stock`: cantidad en stock.

#### Paso 2: Crear una versión parcial del tipo `Product` usando `Partial`
El tipo utilitario `Partial` en TypeScript convierte todas las propiedades de un tipo en opcionales. Esto es útil, por ejemplo, para crear formularios de edición donde no todos los campos del producto deben ser modificados.

```typescript
type PartialProduct = Partial<Product>;
```

Aquí estamos creando un nuevo tipo `PartialProduct`, que es una versión de `Product` en la que todas las propiedades son opcionales. Este tipo sería útil para casos en los que solo necesitamos actualizar ciertas propiedades del producto.

#### Paso 3: Crear una versión limitada del tipo `Product` usando `Pick`
El tipo utilitario `Pick` permite crear un nuevo tipo seleccionando solo algunas propiedades de un tipo existente. En este caso, vamos a crear una versión limitada de `Product` que solo incluye el `name` y el `price`.

```typescript
type ProductSummary = Pick<Product, 'name' | 'price'>;
```

Con `Pick`, estamos seleccionando solo las propiedades `name` y `price` de `Product`, creando un nuevo tipo `ProductSummary` que solo tiene esas dos propiedades. Este tipo sería útil para mostrar una lista resumida de productos.

---

### **Prueba de los tipos con ejemplos**

Ahora podemos usar los tipos `PartialProduct` y `ProductSummary` en funciones o ejemplos para verificar su utilidad.

```typescript
// Ejemplo de un producto completo (Product)
const fullProduct: Product = {
  id: 1,
  name: "Laptop",
  price: 1500,
  description: "High-end gaming laptop",
  category: "Electronics",
  stock: 30,
};

// Ejemplo de un producto parcial (PartialProduct) para edición
const editedProduct: PartialProduct = {
  price: 1400, // Solo estamos actualizando el precio
};

// Ejemplo de un producto resumen (ProductSummary)
const productSummary: ProductSummary = {
  name: "Laptop",
  price: 1500,
};

// Imprimir los ejemplos
console.log("Producto completo:", fullProduct);
console.log("Producto editado (parcial):", editedProduct);
console.log("Resumen del producto:", productSummary);
```

---

### **Respuestas a las preguntas de análisis:**

1. **¿Qué beneficios ofrece el uso de tipos utilitarios en proyectos grandes?**
   - Los tipos utilitarios como `Partial` y `Pick` ayudan a reutilizar y modificar tipos de manera flexible sin necesidad de redefinirlos. Esto es especialmente útil en proyectos grandes donde varios componentes pueden necesitar versiones específicas de los tipos, como formularios de edición, vistas resumidas, o versiones parciales de objetos.
   - Mejoran la mantenibilidad del código, ya que si cambia el tipo original (en este caso `Product`), los tipos derivados también se actualizan automáticamente.

2. **¿Cómo puedes aprovechar la creación dinámica de tipos en tu aplicación?**
   - La creación dinámica de tipos permite adaptarse a diferentes necesidades dentro de una aplicación sin duplicar código. Por ejemplo:
     - **Edición de datos:** Usar `Partial` para formularios donde no todas las propiedades necesitan ser modificadas.
     - **Listas resumidas:** Usar `Pick` para crear versiones limitadas de objetos que solo contengan las propiedades necesarias para mostrar información específica (por ejemplo, nombre y precio de un producto en una lista de productos).
   - Esto también mejora la flexibilidad, ya que puedes crear versiones adaptadas a las diferentes necesidades del front-end, API o bases de datos sin redefinir manualmente cada versión.

---

### **Resumen de los comandos y archivos a crear:**

#### 1. **Crear la carpeta `src` y el archivo `utility-types.ts`:**
```bash
mkdir src
touch src/utility-types.ts
```

#### 2. **Agregar el siguiente código en `src/utility-types.ts`:**

```typescript
// Definición de la interfaz Product
interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
  category: string;
  stock: number;
}

// Creación de un tipo parcial del producto
type PartialProduct = Partial<Product>;

// Creación de un tipo resumen del producto (solo nombre y precio)
type ProductSummary = Pick<Product, 'name' | 'price'>;

// Ejemplo de uso de los tipos

// Producto completo
const fullProduct: Product = {
  id: 1,
  name: "Laptop",
  price: 1500,
  description: "High-end gaming laptop",
  category: "Electronics",
  stock: 30,
};

// Producto parcial (edición)
const editedProduct: PartialProduct = {
  price: 1400,  // Solo actualizamos el precio
};

// Resumen del producto (solo nombre y precio)
const productSummary: ProductSummary = {
  name: "Laptop",
  price: 1500,
};

// Imprimir los ejemplos
console.log("Producto completo:", fullProduct);
console.log("Producto editado (parcial):", editedProduct);
console.log("Resumen del producto:", productSummary);
```

#### 3. **Compilar el código:**
```bash
npx tsc
```

#### 4. **Ejecutar el archivo compilado:**
```bash
node dist/utility-types.js
```

---

### **Estructura final del proyecto:**

```
gestion-productos-typescript/
│
├── src/
│   └── utility-types.ts    # Código del ejercicio con Partial y Pick
│
├── dist/                   # Carpeta para archivos compilados
│   └── utility-types.js
│
├── tsconfig.json           # Configuración de TypeScript
└── package.json            # Proyecto Node.js
```
