### **Ejercicio 6: Uniones de tipos y type intersections**

#### **Descripción del problema:**
Desarrolla un sistema de gestión de usuarios y permisos. Define dos tipos: `AdminUser` y `RegularUser`, cada uno con sus propias propiedades específicas. Luego, crea un tipo que represente a un `User` que pueda ser una **unión de ambos**. Implementa una función que reciba este tipo de usuario y realice acciones distintas según si es un administrador o un usuario regular.

---

### **Solución:**

#### Paso 1: Definir los tipos `AdminUser` y `RegularUser`
Primero, definimos los dos tipos de usuarios con sus respectivas propiedades.

```typescript
// Tipo para un usuario administrador
interface AdminUser {
  username: string;
  isAdmin: true; // Propiedad que siempre es `true` para admin
  adminPermissions: string[]; // Lista de permisos especiales para administradores
}

// Tipo para un usuario regular
interface RegularUser {
  username: string;
  isAdmin: false; // Propiedad que siempre es `false` para usuarios regulares
  userLevel: number; // Nivel del usuario (ej: 1 para básico, 2 para premium, etc.)
}
```

En estos tipos:
- **`AdminUser`** tiene una propiedad `adminPermissions` que contiene una lista de permisos especiales.
- **`RegularUser`** tiene una propiedad `userLevel` que indica el nivel del usuario.

#### Paso 2: Crear una unión de tipos `User`
Creamos un nuevo tipo `User` que puede ser una **unión** de `AdminUser` y `RegularUser`. Esto significa que un `User` puede ser cualquiera de estos dos tipos.

```typescript
type User = AdminUser | RegularUser;
```

#### Paso 3: Implementar la función que gestione el tipo `User`
La función que recibe un `User` puede usar **narrowing** para verificar si el usuario es un administrador o un usuario regular, y luego realizar acciones específicas según el tipo.

```typescript
function handleUser(user: User): void {
  // Verificamos si el usuario es un administrador
  if (user.isAdmin) {
    console.log(`Admin ${user.username} tiene los siguientes permisos: ${user.adminPermissions.join(', ')}`);
  } else {
    // Si no es administrador, entonces es un usuario regular
    console.log(`Usuario regular ${user.username} tiene nivel: ${user.userLevel}`);
  }
}
```

Aquí utilizamos **narrowing** basado en la propiedad `isAdmin`. Si `isAdmin` es `true`, sabemos que el usuario es un administrador; si es `false`, sabemos que es un usuario regular.

---

### **Prueba del código con ejemplos:**

Vamos a probar la función con ejemplos de usuarios administradores y regulares.

```typescript
// Ejemplo de un usuario administrador
const admin: AdminUser = {
  username: "admin123",
  isAdmin: true,
  adminPermissions: ["manage-users", "delete-posts"]
};

// Ejemplo de un usuario regular
const regularUser: RegularUser = {
  username: "user456",
  isAdmin: false,
  userLevel: 2
};

// Ejecutar la función con ambos tipos de usuario
handleUser(admin);
handleUser(regularUser);
```

En este código:
- **`admin`** es un usuario administrador con permisos especiales.
- **`regularUser`** es un usuario regular con un nivel de usuario.

Al ejecutar la función, obtendremos resultados diferentes dependiendo del tipo de usuario que se pase a la función `handleUser`.

---

### **Respuestas a las preguntas:**

1. **¿Cómo manejas las diferencias entre los tipos en una unión sin perder la seguridad de tipos?**
   - Usamos **narrowing**, en este caso verificando la propiedad `isAdmin`. Dado que esta propiedad es exclusiva de cada tipo (`true` para `AdminUser` y `false` para `RegularUser`), TypeScript puede inferir correctamente el tipo dentro de los bloques de código que siguen a cada verificación.

2. **¿Qué ventajas tiene usar intersección de tipos en lugar de herencia?**
   - **Intersecciones de tipos** permiten combinar propiedades de diferentes tipos sin forzar una jerarquía rígida como lo hace la herencia. Esto ofrece más flexibilidad y evita la rigidez de las relaciones de "es un" que se imponen con herencia. Con la intersección de tipos, puedes combinar múltiples tipos en una sola estructura sin crear dependencias fuertes entre ellos.

---

### **Resumen de los pasos y comandos:**

#### 1. **Crear la carpeta `src` y el archivo `user-management.ts`:**
```bash
mkdir src
touch src/user-management.ts
```

#### 2. **Agregar el siguiente código en `src/user-management.ts`:**

```typescript
// Definición de AdminUser y RegularUser
interface AdminUser {
  username: string;
  isAdmin: true;
  adminPermissions: string[];
}

interface RegularUser {
  username: string;
  isAdmin: false;
  userLevel: number;
}

// Unión de tipos
type User = AdminUser | RegularUser;

// Función que maneja los distintos tipos de usuario
function handleUser(user: User): void {
  if (user.isAdmin) {
    console.log(`Admin ${user.username} tiene los siguientes permisos: ${user.adminPermissions.join(', ')}`);
  } else {
    console.log(`Usuario regular ${user.username} tiene nivel: ${user.userLevel}`);
  }
}

// Ejemplos
const admin: AdminUser = {
  username: "admin123",
  isAdmin: true,
  adminPermissions: ["manage-users", "delete-posts"]
};

const regularUser: RegularUser = {
  username: "user456",
  isAdmin: false,
  userLevel: 2
};

// Probar la función con ambos tipos
handleUser(admin);
handleUser(regularUser);
```

#### 3. **Compilar el código:**
```bash
npx tsc
```

#### 4. **Ejecutar el archivo compilado:**
```bash
node dist/user-management.js
```

---

### **Estructura final del proyecto:**

```
gestion-usuarios-typescript/
│
├── src/
│   └── user-management.ts     # Código del ejercicio con AdminUser y RegularUser
│
├── dist/                      # Carpeta para archivos compilados
│   └── user-management.js
│
├── tsconfig.json              # Configuración de TypeScript
└── package.json               # Proyecto Node.js
```
