### **Ejercicio 7: Funciones genéricas y promesas**

#### **Descripción del problema:**
Implementa una función genérica que acepte un array de cualquier tipo y devuelva una promesa que se resuelva con una versión filtrada del array. La función debe ser capaz de **filtrar elementos que sean `null` o `undefined`**.

---

### **Solución:**

#### **Paso 1: Definir la función genérica**
Para que la función acepte un array de cualquier tipo, utilizamos **generics** en TypeScript. El tipo genérico se representa con `<T>`, lo que permite que la función trabaje con diferentes tipos de datos.

```typescript
function filterNullAndUndefined<T>(arr: T[]): Promise<T[]> {
  return new Promise((resolve) => {
    const filteredArray = arr.filter(item => item !== null && item !== undefined);
    resolve(filteredArray);
  });
}
```

### **Explicación del código:**
- **`<T>`**: Es un **tipo genérico**. Esto le indica a TypeScript que la función puede trabajar con cualquier tipo de dato (por ejemplo, `string`, `number`, `boolean`, etc.).
- **`arr: T[]`**: El parámetro `arr` es un array de cualquier tipo (`T[]`), lo que significa que puede ser un array de números, strings, objetos, etc.
- **Promesa**: La función devuelve una promesa que, al resolverse, contiene el array filtrado.
- **Filtro**: Dentro de la promesa, utilizamos el método `.filter()` para eliminar cualquier elemento que sea `null` o `undefined` del array.

---

### **Paso 2: Probar la función con diferentes tipos de datos**
Podemos probar la función con arrays que contengan diferentes tipos de datos (números, strings, etc.) y verificar que los valores `null` y `undefined` se eliminen correctamente.

```typescript
// Prueba con un array de números
const numbers = [1, 2, null, 4, undefined, 6];
filterNullAndUndefined(numbers).then(result => {
  console.log('Filtrado de números:', result);  // [1, 2, 4, 6]
});

// Prueba con un array de strings
const strings = ['hello', null, 'world', undefined, 'typescript'];
filterNullAndUndefined(strings).then(result => {
  console.log('Filtrado de strings:', result);  // ['hello', 'world', 'typescript']
});

// Prueba con un array de objetos
const objects = [{ name: 'Alice' }, null, { name: 'Bob' }, undefined];
filterNullAndUndefined(objects).then(result => {
  console.log('Filtrado de objetos:', result);  // [{ name: 'Alice' }, { name: 'Bob' }]
});
```

---

### **Respuestas a las preguntas de análisis:**

1. **¿Cuáles son las ventajas de usar generics en TypeScript en comparación con funciones normales?**
   - **Flexibilidad y reutilización**: Los generics permiten que las funciones y clases trabajen con cualquier tipo de dato sin perder la seguridad de tipos. Esto evita duplicar código, ya que no necesitamos escribir una función para cada tipo de dato (números, strings, objetos, etc.).
   - **Seguridad de tipos**: Con generics, TypeScript puede inferir el tipo correcto en cada instancia de la función, lo que ayuda a evitar errores de tipo en tiempo de compilación. El código sigue siendo seguro sin importar el tipo de datos con el que esté trabajando.

2. **¿Cómo manejas los errores de tipos en funciones que devuelven promesas?**
   - Para manejar errores en funciones que devuelven promesas, puedes usar `.catch()` para capturar los errores que ocurren dentro de la promesa. Además, es una buena práctica tipar correctamente los errores que podrías esperar.
   
   Ejemplo:
   ```typescript
   filterNullAndUndefined(numbers)
     .then(result => console.log(result))
     .catch(error => console.error('Error:', error));
   ```
   Esto asegura que cualquier error que ocurra durante la ejecución de la promesa se capture y maneje adecuadamente.

---

### **Resumen de los pasos y comandos para implementar el ejercicio:**

#### 1. **Crear la carpeta `src` y el archivo `generic-promise.ts`:**
```bash
mkdir src
touch src/generic-promise.ts
```

#### 2. **Agregar el código en `src/generic-promise.ts`:**

```typescript
// Definición de la función genérica que filtra valores null y undefined
function filterNullAndUndefined<T>(arr: T[]): Promise<T[]> {
  return new Promise((resolve) => {
    const filteredArray = arr.filter(item => item !== null && item !== undefined);
    resolve(filteredArray);
  });
}

// Prueba con un array de números
const numbers = [1, 2, null, 4, undefined, 6];
filterNullAndUndefined(numbers).then(result => {
  console.log('Filtrado de números:', result);  // [1, 2, 4, 6]
});

// Prueba con un array de strings
const strings = ['hello', null, 'world', undefined, 'typescript'];
filterNullAndUndefined(strings).then(result => {
  console.log('Filtrado de strings:', result);  // ['hello', 'world', 'typescript']
});

// Prueba con un array de objetos
const objects = [{ name: 'Alice' }, null, { name: 'Bob' }, undefined];
filterNullAndUndefined(objects).then(result => {
  console.log('Filtrado de objetos:', result);  // [{ name: 'Alice' }, { name: 'Bob' }]
});
```

#### 3. **Compilar el código:**
```bash
npx tsc
```

#### 4. **Ejecutar el archivo compilado:**
```bash
node dist/generic-promise.js
```

---

### **Estructura final del proyecto:**

```
funciones-genericas-typescript/
│
├── src/
│   └── generic-promise.ts     # Código del ejercicio con función genérica y promesas
│
├── dist/                      # Carpeta para archivos compilados
│   └── generic-promise.js
│
├── tsconfig.json              # Configuración de TypeScript
└── package.json               # Proyecto Node.js
```
