### **Ejercicio 8: OOP en TypeScript con interfaces y clases**

#### **Descripción del problema:**
Crea una clase `Vehicle` que implemente una interfaz `Drivable`. La interfaz debe tener un método `drive()` y la clase debe incluir propiedades como `speed` y `fuel`. Implementa la clase para distintos tipos de vehículos como `Car` y `Motorcycle`, y utiliza el **polimorfismo** para manejar ambos tipos de vehículos de manera intercambiable.

---

### **Solución:**

#### **Paso 1: Definir la interfaz `Drivable`**
Primero, definimos una interfaz `Drivable` que contiene el método `drive()` y algunas propiedades comunes como `speed` y `fuel`.

```typescript
// Interfaz Drivable
interface Drivable {
  speed: number;  // Velocidad del vehículo
  fuel: number;   // Cantidad de combustible
  drive(): void;  // Método para conducir el vehículo
}
```

La interfaz `Drivable` asegura que cualquier clase que la implemente tenga las propiedades `speed`, `fuel` y el método `drive()`.

#### **Paso 2: Implementar la clase `Vehicle`**
Creamos la clase base `Vehicle`, que implementa la interfaz `Drivable`.

```typescript
// Clase base Vehicle
class Vehicle implements Drivable {
  constructor(public speed: number, public fuel: number) {}

  drive(): void {
    if (this.fuel > 0) {
      console.log(`El vehículo está conduciendo a ${this.speed} km/h`);
      this.fuel -= 1;
    } else {
      console.log("No hay suficiente combustible para conducir.");
    }
  }
}
```

- **`Vehicle`**: Esta es la clase base que implementa la interfaz `Drivable`.
- El método `drive()` verifica si el vehículo tiene combustible antes de conducir. Si hay combustible, se reduce en 1 unidad después de conducir.

#### **Paso 3: Crear las clases `Car` y `Motorcycle` que extienden `Vehicle`**
Ahora, implementamos clases específicas para vehículos como `Car` y `Motorcycle`. Ambas clases extenderán `Vehicle` y tendrán propiedades adicionales o personalizaciones.

```typescript
// Clase Car que extiende Vehicle
class Car extends Vehicle {
  constructor(speed: number, fuel: number, public doors: number) {
    super(speed, fuel);  // Llama al constructor de Vehicle
  }

  drive(): void {
    console.log("El coche está conduciendo.");
    super.drive();  // Llama al método drive() de la clase base
  }
}

// Clase Motorcycle que extiende Vehicle
class Motorcycle extends Vehicle {
  constructor(speed: number, fuel: number) {
    super(speed, fuel);  // Llama al constructor de Vehicle
  }

  drive(): void {
    console.log("La motocicleta está conduciendo.");
    super.drive();  // Llama al método drive() de la clase base
  }
}
```

- **`Car`**: Añade la propiedad `doors` que representa el número de puertas en el coche.
- **`Motorcycle`**: No añade propiedades adicionales, pero personaliza el mensaje de `drive()`.

#### **Paso 4: Uso del polimorfismo**
El **polimorfismo** nos permite manejar tanto un `Car` como una `Motorcycle` utilizando la misma interfaz `Drivable`. Esto significa que podemos tener un array de vehículos, y cada uno puede ser tratado de la misma manera, aunque sean diferentes clases.

```typescript
// Función para conducir cualquier vehículo
function testDrive(vehicle: Drivable): void {
  vehicle.drive();
}

// Crear instancias de Car y Motorcycle
const myCar = new Car(120, 10, 4);
const myMotorcycle = new Motorcycle(100, 5);

// Uso de polimorfismo
testDrive(myCar);         // "El coche está conduciendo. El vehículo está conduciendo a 120 km/h"
testDrive(myMotorcycle);  // "La motocicleta está conduciendo. El vehículo está conduciendo a 100 km/h"
```

La función `testDrive()` acepta cualquier vehículo que implemente la interfaz `Drivable`, por lo que puede manejar tanto coches como motocicletas de manera intercambiable.

---

### **Respuestas a las preguntas de análisis:**

1. **¿Cómo implementas la reutilización de código con interfaces en TypeScript?**
   - Las interfaces permiten la reutilización de código al definir contratos que las clases deben cumplir. En este caso, cualquier clase que implemente `Drivable` debe tener las propiedades `speed` y `fuel`, y el método `drive()`. Esto asegura que podemos reutilizar lógica común en múltiples clases que implementan la misma interfaz, sin tener que duplicar código.
   
2. **¿Qué beneficios tiene el polimorfismo en aplicaciones web?**
   - **Flexibilidad**: El polimorfismo permite que diferentes objetos (por ejemplo, `Car` y `Motorcycle`) sean tratados de la misma manera. Esto facilita la extensión del código sin cambiar las funciones que lo utilizan.
   - **Mantenimiento**: Al usar interfaces y polimorfismo, puedes añadir nuevas clases (como `Truck` o `Bicycle`) sin cambiar la lógica existente que trabaja con la interfaz `Drivable`.
   - **Escalabilidad**: Puedes manejar diferentes tipos de vehículos (o cualquier otra entidad) de manera intercambiable, lo que es ideal para aplicaciones grandes y complejas donde se manejan múltiples tipos de objetos de manera uniforme.

---

### **Resumen de los pasos y comandos para implementar el ejercicio:**

#### 1. **Crear la carpeta `src` y el archivo `vehicle.ts`:**
```bash
mkdir src
touch src/vehicle.ts
```

#### 2. **Agregar el código en `src/vehicle.ts`:**

```typescript
// Interfaz Drivable
interface Drivable {
  speed: number;
  fuel: number;
  drive(): void;
}

// Clase base Vehicle que implementa Drivable
class Vehicle implements Drivable {
  constructor(public speed: number, public fuel: number) {}

  drive(): void {
    if (this.fuel > 0) {
      console.log(`El vehículo está conduciendo a ${this.speed} km/h`);
      this.fuel -= 1;
    } else {
      console.log("No hay suficiente combustible para conducir.");
    }
  }
}

// Clase Car que extiende Vehicle
class Car extends Vehicle {
  constructor(speed: number, fuel: number, public doors: number) {
    super(speed, fuel);
  }

  drive(): void {
    console.log("El coche está conduciendo.");
    super.drive();
  }
}

// Clase Motorcycle que extiende Vehicle
class Motorcycle extends Vehicle {
  constructor(speed: number, fuel: number) {
    super(speed, fuel);
  }

  drive(): void {
    console.log("La motocicleta está conduciendo.");
    super.drive();
  }
}

// Función que utiliza el polimorfismo
function testDrive(vehicle: Drivable): void {
  vehicle.drive();
}

// Instancias de Car y Motorcycle
const myCar = new Car(120, 10, 4);
const myMotorcycle = new Motorcycle(100, 5);

// Uso de la función polimórfica
testDrive(myCar);         // Conduce el coche
testDrive(myMotorcycle);  // Conduce la motocicleta
```

#### 3. **Compilar el código:**
```bash
npx tsc
```

#### 4. **Ejecutar el archivo compilado:**
```bash
node dist/vehicle.js
```

---

### **Estructura final del proyecto:**

```
oop-typescript/
│
├── src/
│   └── vehicle.ts          # Código del ejercicio con Vehicle, Car y Motorcycle
│
├── dist/                   # Carpeta para archivos compilados
│   └── vehicle.js
│
├── tsconfig.json           # Configuración de TypeScript
└── package.json            # Proyecto Node.js
```
