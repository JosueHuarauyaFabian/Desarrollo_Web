### **Ejercicio 9: Promesas y tipado avanzado de funciones**

#### **Descripción del problema:**
Desarrolla una API que gestione una lista de tareas pendientes (to-do list). Las funciones de la API deben incluir:

- **Obtener todas las tareas.**
- **Agregar una nueva tarea.**
- **Marcar una tarea como completada.**

Cada función debe devolver una promesa tipada adecuadamente que refleje el éxito o fracaso de la operación. Asegúrate de manejar correctamente los errores y los casos en los que las promesas fallen.

---

### **Solución:**

#### Paso 1: Definir el tipo de tarea
Primero, necesitamos definir la estructura de los objetos de tipo `Task`. Esta interfaz representará una tarea en nuestra lista de tareas pendientes.

```typescript
// Definición del tipo de Tarea
interface Task {
  id: number;
  title: string;
  completed: boolean;
}
```

---

#### Paso 2: Crear la lista de tareas
Implementamos una lista de tareas simulada que la API gestionará. Para simular una base de datos o almacenamiento, usaremos un array.

```typescript
// Lista simulada de tareas
let tasks: Task[] = [
  { id: 1, title: "Aprender TypeScript", completed: false },
  { id: 2, title: "Practicar ejercicios", completed: false },
];
```

---

#### Paso 3: Implementar las funciones de la API
A continuación, implementamos las funciones de la API que gestionarán las tareas. Cada función devolverá una promesa tipada.

1. **Obtener todas las tareas**: Devuelve una promesa con la lista de tareas.
2. **Agregar una nueva tarea**: Añade una tarea nueva a la lista y devuelve una promesa con la tarea agregada.
3. **Marcar una tarea como completada**: Marca una tarea como completada según el ID y devuelve una promesa.

---

##### a) **Función para obtener todas las tareas**

```typescript
function getAllTasks(): Promise<Task[]> {
  return new Promise((resolve) => {
    resolve(tasks);
  });
}
```

Esta función devuelve una promesa que se resuelve con la lista de tareas actuales.

---

##### b) **Función para agregar una nueva tarea**

```typescript
function addTask(title: string): Promise<Task> {
  return new Promise((resolve, reject) => {
    if (!title) {
      return reject("El título de la tarea no puede estar vacío.");
    }
    const newTask: Task = {
      id: tasks.length + 1,
      title,
      completed: false,
    };
    tasks.push(newTask);
    resolve(newTask);
  });
}
```

La función `addTask()` agrega una nueva tarea a la lista. Si el título está vacío, la promesa se rechaza con un mensaje de error. Si la tarea se crea con éxito, la promesa se resuelve con la nueva tarea.

---

##### c) **Función para marcar una tarea como completada**

```typescript
function completeTask(taskId: number): Promise<Task> {
  return new Promise((resolve, reject) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) {
      return reject("Tarea no encontrada.");
    }
    task.completed = true;
    resolve(task);
  });
}
```

La función `completeTask()` busca una tarea por su ID. Si no se encuentra, la promesa se rechaza con un error. Si la tarea se encuentra, se marca como completada y la promesa se resuelve con la tarea actualizada.

---

### **Prueba de las funciones**

Probemos las funciones de la API con algunas llamadas y capturemos posibles errores.

```typescript
// Obtener todas las tareas
getAllTasks().then(tasks => {
  console.log("Tareas:", tasks);
}).catch(error => console.error("Error:", error));

// Agregar una tarea nueva
addTask("Estudiar promesas en TypeScript")
  .then(newTask => console.log("Nueva tarea agregada:", newTask))
  .catch(error => console.error("Error al agregar tarea:", error));

// Marcar una tarea como completada
completeTask(1)
  .then(updatedTask => console.log("Tarea completada:", updatedTask))
  .catch(error => console.error("Error al completar tarea:", error));
```

---

### **Respuestas a las preguntas de análisis:**

1. **¿Cómo decides qué tipo debe devolver una promesa en TypeScript?**
   - El tipo de retorno de una promesa se decide en función del valor que se espera que se resuelva cuando la operación asíncrona tenga éxito. En este caso:
     - **`getAllTasks`** devuelve una promesa de un array de tareas (`Promise<Task[]>`).
     - **`addTask`** devuelve una promesa de un objeto `Task` (`Promise<Task>`).
     - **`completeTask`** también devuelve una promesa de un objeto `Task` (`Promise<Task>`).
   - Si se espera que la promesa devuelva un valor específico, se debe tipar ese valor para aprovechar al máximo la seguridad de tipos de TypeScript.

2. **¿Cómo manejas los errores dentro de promesas en aplicaciones web?**
   - Los errores en promesas se manejan utilizando `.catch()` para capturar errores que pueden ocurrir dentro de las funciones asíncronas. Además, es una buena práctica rechazar la promesa con mensajes de error específicos en caso de que una operación falle.
   - También se pueden manejar los errores de forma más centralizada usando `try`/`catch` con la sintaxis de `async`/`await` para capturar los errores de manera más estructurada:
     ```typescript
     async function completeTaskWithErrorHandling(taskId: number) {
       try {
         const task = await completeTask(taskId);
         console.log("Tarea completada:", task);
       } catch (error) {
         console.error("Error:", error);
       }
     }

     completeTaskWithErrorHandling(1);
     ```

---

### **Resumen de los pasos y comandos para implementar el ejercicio:**

#### 1. **Crear la carpeta `src` y el archivo `todo-api.ts`:**
```bash
mkdir src
touch src/todo-api.ts
```

#### 2. **Agregar el código en `src/todo-api.ts`:**

```typescript
// Definición de la interfaz Task
interface Task {
  id: number;
  title: string;
  completed: boolean;
}

// Lista simulada de tareas
let tasks: Task[] = [
  { id: 1, title: "Aprender TypeScript", completed: false },
  { id: 2, title: "Practicar ejercicios", completed: false },
];

// Función para obtener todas las tareas
function getAllTasks(): Promise<Task[]> {
  return new Promise((resolve) => {
    resolve(tasks);
  });
}

// Función para agregar una nueva tarea
function addTask(title: string): Promise<Task> {
  return new Promise((resolve, reject) => {
    if (!title) {
      return reject("El título de la tarea no puede estar vacío.");
    }
    const newTask: Task = {
      id: tasks.length + 1,
      title,
      completed: false,
    };
    tasks.push(newTask);
    resolve(newTask);
  });
}

// Función para marcar una tarea como completada
function completeTask(taskId: number): Promise<Task> {
  return new Promise((resolve, reject) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) {
      return reject("Tarea no encontrada.");
    }
    task.completed = true;
    resolve(task);
  });
}

// Pruebas de las funciones
getAllTasks().then(tasks => {
  console.log("Tareas:", tasks);
}).catch(error => console.error("Error:", error));

addTask("Estudiar promesas en TypeScript")
  .then(newTask => console.log("Nueva tarea agregada:", newTask))
  .catch(error => console.error("Error al agregar tarea:", error));

completeTask(1)
  .then(updatedTask => console.log("Tarea completada:", updatedTask))
  .catch(error => console.error("Error al completar tarea:", error));
```

#### 3. **Compilar el código:**
```bash
npx tsc
```

#### 4. **Ejecutar el archivo compilado:**
```bash
node dist/todo-api.js
```

---

### **Estructura final del proyecto:**

```
gestion-tareas-api/
│
├── src/
│   └── todo-api.ts         # Código del ejercicio con funciones de la API de tareas
│
├── dist/                   # Carpeta para archivos compilados
│   └── todo-api.js
│
├── tsconfig.json           # Configuración de TypeScript
└── package.json            # Proyecto Node.js
```

