
### Paso 1: Instalación de Node.js y npm (si aún no lo tienes)
1. **Verificar la instalación**:
   - Abre la terminal y ejecuta:
     ```bash
     node -v
     npm -v
     ```

### Paso 2: Crear un Proyecto Básico de Express
1. **Inicializar el Proyecto**:
   - Crea una carpeta para el proyecto y navega a ella:
     ```bash
     mkdir mi-aplicacion-express
     cd mi-aplicacion-express
     ```
   - Inicializa un proyecto de Node.js:
     ```bash
     npm init -y
     ```

2. **Instalar Express**:
   - Instala Express en tu proyecto:
     ```bash
     npm install express@4
     ```

3. **Crear una Aplicación Básica de Hello World**:
   - Crea un archivo `helloWorld.js` con el siguiente contenido:
     ```javascript
     import express from 'express';
     const app = express();
     const port = 3000;

     app.get('/', (req, res) => {
       res.send('Hello World desde Express!');
     });

     app.listen(port, () => {
       console.log(`App escuchando en el puerto ${port}`);
     });
     ```
   - Ejecuta la aplicación:
     ```bash
     node helloWorld.js
     ```
   - Visita [http://localhost:3000](http://localhost:3000) en tu navegador para ver el mensaje.

### Paso 3: Generar una Aplicación con express-generator
1. **Instalar express-generator**:
   ```bash
   npx express-generator@4
   ```
2. **Crear una Nueva Aplicación con express-generator**:
   - Ejecuta el generador en una nueva carpeta:
     ```bash
     mkdir mi-aplicacion-generada
     cd mi-aplicacion-generada
     npx express-generator@4
     ```
   - Instala las dependencias:
     ```bash
     npm install
     ```
   - Inicia la aplicación generada:
     ```bash
     npm start
     ```

### Paso 4: Configuración y Uso de un Motor de Plantillas (EJS)
1. **Instalar EJS**:
   ```bash
   npm install ejs@3
   ```

2. **Configurar EJS y Crear una Vista**:
   - Crea un archivo `helloWorldTemplate.js` y agrega el siguiente código:
     ```javascript
     import express from 'express';
     const app = express();
     const port = 3000;

     app.set('view engine', 'ejs');

     app.get('/', (req, res) => {
       res.render('index', {
         title: 'Aplicación Express',
         subtitle: 'Usando EJS como plantilla'
       });
     });

     app.listen(port, () => {
       console.log(`App corriendo en http://localhost:${port}`);
     });
     ```
   - Crea la carpeta `views` y el archivo `index.ejs`:
     ```html
     <!DOCTYPE html>
     <html lang="en">
     <head>
       <meta charset="UTF-8">
       <title><%= title %></title>
     </head>
     <body>
       <h1><%= title %></h1>
       <h2><%= subtitle %></h2>
     </body>
     </html>
     ```

3. **Ejecutar la Aplicación**:
   ```bash
   node helloWorldTemplate.js
   ```
   - Visita [http://localhost:3000](http://localhost:3000) para ver el resultado renderizado.

### Paso 5: Creación de Rutas Estáticas y Dinámicas
1. **Crear Rutas en Express**:
   - Agrega rutas estáticas en `helloWorld.js`:
     ```javascript
     app.get('/users', (req, res) => {
       res.send('Lista de usuarios');
     });

     app.get('/users/:id', (req, res) => {
       res.send(`Usuario con ID: ${req.params.id}`);
     });
     ```
2. **Usar Parámetros de Consulta**:
   ```javascript
   app.get('/films', (req, res) => {
     const { category, director } = req.query;
     res.send(`Buscando películas de la categoría ${category} dirigidas por ${director}`);
   });
   ```

### Paso 6: Manejo de Respuestas HTTP
1. **Establecer Códigos de Estado y Redirecciones**:
   ```javascript
   app.get('/error', (req, res) => {
     res.status(500).send('Error interno del servidor');
   });

   app.get('/redirect', (req, res) => {
     res.redirect('https://example.com');
   });
   ```

### Paso 7: Implementación de Middleware
1. **Crear un Middleware de Manejo de Errores**:
   ```javascript
   app.use((err, req, res, next) => {
     console.error(err.stack);
     res.status(500).send('¡Algo salió mal!');
   });
   ```

### Paso 8: Uso de la Herramienta de Depuración
1. **Ejecutar la Aplicación con Depuración**:
   ```bash
   DEBUG=express:* npm start
   ```

### Paso 9: Servir Archivos Estáticos y Descargas
1. **Servir Archivos Estáticos**:
   ```javascript
   app.use(express.static('public'));
   ```
2. **Enviar Archivos para Descargar**:
   ```javascript
   app.get('/download', (req, res) => {
     res.download('path/to/file.txt');
   });
   ```

### Paso 10: Procesamiento de Datos de Solicitudes
1. **Instalar Middleware de Procesamiento de Datos**:
   ```bash
   npm install body-parser
   ```

2. **Configurar y Usar Middleware**:
   ```javascript
   import bodyParser from 'body-parser';
   app.use(bodyParser.json());
   ```